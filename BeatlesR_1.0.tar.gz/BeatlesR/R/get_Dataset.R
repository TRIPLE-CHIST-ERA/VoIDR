get_Dataset <- function(properties = c("has_sha256", "modified", "distinctObjects", "distinctSubjects", "properties", "triples")){
    propDict <- list()
    propDict[c("has_sha256", "modified", "distinctObjects", "distinctSubjects", "properties", "triples")] <- c("http://example.org/has_sha256", "http://purl.org/dc/terms/modified", "http://rdfs.org/ns/void#distinctObjects", "http://rdfs.org/ns/void#distinctSubjects", "http://rdfs.org/ns/void#properties", "http://rdfs.org/ns/void#triples")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Dataset a <',"http://rdfs.org/ns/void#Dataset",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Dataset ?p ?value
                  }')
    long_df <- SPARQL_query('http://localhost:7200/repositories/beatles', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }