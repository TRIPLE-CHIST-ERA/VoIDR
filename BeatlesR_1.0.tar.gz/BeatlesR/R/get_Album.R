get_Album <- function(properties = c("date", "description", "name", "artist", "producer", "track")){
    propDict <- list()
    propDict[c("date", "description", "name", "artist", "producer", "track")] <- c("http://stardog.com/tutorial/date", "http://stardog.com/tutorial/description", "http://stardog.com/tutorial/name", "http://stardog.com/tutorial/artist", "http://stardog.com/tutorial/producer", "http://stardog.com/tutorial/track")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Album a <',"http://stardog.com/tutorial/Album",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Album ?p ?value
                  }')
    long_df <- SPARQL_query('http://localhost:7200/repositories/beatles', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }