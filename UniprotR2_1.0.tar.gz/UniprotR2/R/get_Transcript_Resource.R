#' @title get_Transcript_Resource
#' @description Transcript Resource
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * transcribedFrom -- transcribed from
#'  * translatedTo -- translated to
#'  * sameAs -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Transcript_Resource <- function(properties = list(dataProperties = list(nonunique = "rdfs_comment"), objectProperties = list(nonunique = c("transcribedFrom", "translatedTo", "rdfs_seeAlso", "sameAs"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_comment = "rdfs:comment", transcribedFrom = "http://purl.uniprot.org/core/transcribedFrom", translatedTo = "http://purl.uniprot.org/core/translatedTo", rdfs_seeAlso = "rdfs:seeAlso", sameAs = "http://www.w3.org/2002/07/owl#sameAs")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(nonunique = "rdfs_comment"), objectProperties = list(nonunique = c("transcribedFrom", "translatedTo", "rdfs_seeAlso", "sameAs")))
   sparql <- makeSparql(propDict[flatProps],'Transcript_Resource', 'http://purl.uniprot.org/core/Transcript_Resource', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Transcript_Resource',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }