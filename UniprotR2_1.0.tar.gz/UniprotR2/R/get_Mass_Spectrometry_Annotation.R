#' @title get_Mass_Spectrometry_Annotation
#' @description Indicates the mass of a sequence determined by mass spectrometry.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * measuredError -- The magnitude of the error of a value that was measured.
#'  * measuredValue -- A value that was measured.
#'  * sequence -- An amino acid sequence.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Mass_Spectrometry_Annotation <- function(properties = list(dataProperties = list(unique = c("measuredError", "measuredValue"), nonunique = "rdfs_comment"), objectProperties = list(nonunique = "sequence")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(measuredError = "http://purl.uniprot.org/core/measuredError", measuredValue = "http://purl.uniprot.org/core/measuredValue", rdfs_comment = "rdfs:comment", sequence = "http://purl.uniprot.org/core/sequence")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("measuredError", "measuredValue"), nonunique = "rdfs_comment"), objectProperties = list(nonunique = "sequence"))
   sparql <- makeSparql(propDict[flatProps],'Mass_Spectrometry_Annotation', 'http://purl.uniprot.org/core/Mass_Spectrometry_Annotation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Mass_Spectrometry_Annotation',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }