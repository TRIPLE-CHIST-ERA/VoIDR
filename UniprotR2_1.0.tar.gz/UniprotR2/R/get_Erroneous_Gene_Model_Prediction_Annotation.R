#' @title get_Erroneous_Gene_Model_Prediction_Annotation
#' @description Erroneous Gene Model Prediction
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * sequence -- An amino acid sequence.
#'  * conflictingSequence -- conflicting sequence
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Erroneous_Gene_Model_Prediction_Annotation <- function(properties = list(dataProperties = list(nonunique = "rdfs_comment"), objectProperties = list(nonunique = c("conflictingSequence", "sequence"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_comment = "rdfs:comment", conflictingSequence = "http://purl.uniprot.org/core/conflictingSequence", sequence = "http://purl.uniprot.org/core/sequence")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(nonunique = "rdfs_comment"), objectProperties = list(nonunique = c("conflictingSequence", "sequence")))
   sparql <- makeSparql(propDict[flatProps],'Erroneous_Gene_Model_Prediction_Annotation', 'http://purl.uniprot.org/core/Erroneous_Gene_Model_Prediction_Annotation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Erroneous_Gene_Model_Prediction_Annotation',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }