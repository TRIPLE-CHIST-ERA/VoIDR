#' @title get_Database
#' @description Metadata for a life science database.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * linkIsExplicit -- True if the Database is linked by an explicit action to UniProt, false if it is done using a simple hardcoded rule.
#'  * urlTemplate -- An string template that can be used to figure out from the database id what html page talks about it.
#'  * category -- category
#'  * abbreviation -- -
#'  * identifier -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Database <- function(properties = list(dataProperties = list(unique = c("category", "abbreviation", "linkIsExplicit", "urlTemplate"), nonunique = c("identifier", "rdfs_comment", "rdfs_label")), objectProperties = list(nonunique = "citation")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(category = "http://purl.uniprot.org/core/category", abbreviation = "http://purl.uniprot.org/core/abbreviation", linkIsExplicit = "http://purl.uniprot.org/core/linkIsExplicit", urlTemplate = "http://purl.uniprot.org/core/urlTemplate", identifier = "http://purl.org/dc/terms/identifier", rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label", citation = "http://purl.uniprot.org/core/citation")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("category", "abbreviation", "linkIsExplicit", "urlTemplate"), nonunique = c("identifier", "rdfs_comment", "rdfs_label")), objectProperties = list(nonunique = "citation"))
   sparql <- makeSparql(propDict[flatProps],'Database', 'http://purl.uniprot.org/core/Database', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Database',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }