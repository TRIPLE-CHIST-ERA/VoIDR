#' @title get_OneOfPosition
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * reference -- -
#'  * possiblePosition -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_OneOfPosition <- function(properties = list(objectProperties = list(unique = c("possiblePosition", "reference"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(possiblePosition = "http://biohackathon.org/resource/faldo#possiblePosition", reference = "http://biohackathon.org/resource/faldo#reference")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(objectProperties = list(unique = c("possiblePosition", "reference")))
   sparql <- makeSparql(propDict[flatProps],'OneOfPosition', 'http://biohackathon.org/resource/faldo#OneOfPosition', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('OneOfPosition',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }