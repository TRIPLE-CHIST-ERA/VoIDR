print.sparql_string <- function(x) cat(x)
