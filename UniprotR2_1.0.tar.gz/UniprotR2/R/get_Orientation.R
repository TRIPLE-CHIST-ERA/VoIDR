#' @title get_Orientation
#' @description Orientation
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * alias -- An alternative name used in the flat text format.
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Orientation <- function(properties = list(dataProperties = list(unique = c("prefLabel", "alias"), nonunique = "rdfs_comment")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", alias = "http://purl.uniprot.org/core/alias", rdfs_comment = "rdfs:comment")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("prefLabel", "alias"), nonunique = "rdfs_comment"))
   sparql <- makeSparql(propDict[flatProps],'Orientation', 'http://purl.uniprot.org/core/Orientation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Orientation',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }