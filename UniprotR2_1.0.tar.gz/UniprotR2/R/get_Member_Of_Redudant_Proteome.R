#' @title get_Member_Of_Redudant_Proteome
#' @description get_Member_Of_Redudant_Proteome
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Member_Of_Redudant_Proteome <- function(properties = list(dataProperties = list(unique = c("created", "mnemonic", "modified", "reviewed", "version", "obsolete"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(created = "http://purl.uniprot.org/core/created", mnemonic = "http://purl.uniprot.org/core/mnemonic", modified = "http://purl.uniprot.org/core/modified", reviewed = "http://purl.uniprot.org/core/reviewed", version = "http://purl.uniprot.org/core/version", obsolete = "http://purl.uniprot.org/core/obsolete")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("created", "mnemonic", "modified", "reviewed", "version", "obsolete")))
   sparql <- makeSparql(propDict[flatProps],'Member_Of_Redudant_Proteome', 'http://purl.uniprot.org/core/Member_Of_Redudant_Proteome', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Member_Of_Redudant_Proteome',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }