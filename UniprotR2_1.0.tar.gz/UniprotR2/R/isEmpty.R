isEmpty <- function(x) length(x) == 0
