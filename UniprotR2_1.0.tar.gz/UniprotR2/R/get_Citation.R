#' @title get_Citation
#' @description Description of a publication from which data was obtained.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * identifier -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Citation <- function(properties = list(dataProperties = list(nonunique = "identifier")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(identifier = "http://purl.org/dc/terms/identifier")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(nonunique = "identifier"))
   sparql <- makeSparql(propDict[flatProps],'Citation', 'http://purl.uniprot.org/core/Citation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Citation',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }