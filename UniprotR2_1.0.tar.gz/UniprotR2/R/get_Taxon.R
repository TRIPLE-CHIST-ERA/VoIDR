#' @title get_Taxon
#' @description An element of a taxonomy for classifying life forms.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * mnemonic -- A rememberable string that can be used to find entries, not a stable identifier!
#'  * mnemonic -- A easy to remember identifier for a UniProtKB entry, but it is not a stable identifier and should not be used by programs to identify entries.
#'  * obsolete -- True if this resource has been replaced or deleted.
#'  * replacedBy -- A resource that replaces this resource.
#'  * partOfLineage -- True for taxa that can appear as part of an organism's non abbreviated lineage. In the flatfile and XML views of an UniProt entry (as well as at INSDC) only these taxonomic nodes are shown.
#'  * replaces -- A resource that is replaced by this resource.
#'  * commonName -- common name
#'  * host -- host
#'  * otherName -- other name
#'  * scientificName -- scientific name
#'  * strain -- strain
#'  * synonym -- synonym
#'  * narrowerTransitive -- -
#'  * depiction -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Taxon <- function(properties = list(dataProperties = list(unique = c("mnemonic", "obsolete", "commonName", "partOfLineage", "scientificName", "synonym"), nonunique = "otherName"), objectProperties = list(nonunique = c("replaces", "rdfs_subClassOf", "replacedBy", "host", "strain", "narrowerTransitive", "depiction"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(mnemonic = "http://purl.uniprot.org/core/mnemonic", obsolete = "http://purl.uniprot.org/core/obsolete", commonName = "http://purl.uniprot.org/core/commonName", partOfLineage = "http://purl.uniprot.org/core/partOfLineage", scientificName = "http://purl.uniprot.org/core/scientificName", synonym = "http://purl.uniprot.org/core/synonym", otherName = "http://purl.uniprot.org/core/otherName", replaces = "http://purl.uniprot.org/core/replaces", rdfs_subClassOf = "rdfs:subClassOf", replacedBy = "http://purl.uniprot.org/core/replacedBy", 
    host = "http://purl.uniprot.org/core/host", strain = "http://purl.uniprot.org/core/strain", narrowerTransitive = "http://www.w3.org/2004/02/skos/core#narrowerTransitive", depiction = "http://xmlns.com/foaf/0.1/depiction")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("mnemonic", "obsolete", "commonName", "partOfLineage", "scientificName", "synonym"), nonunique = "otherName"), objectProperties = list(nonunique = c("replaces", "rdfs_subClassOf", "replacedBy", "host", "strain", "narrowerTransitive", "depiction")))
   sparql <- makeSparql(propDict[flatProps],'Taxon', 'http://purl.uniprot.org/core/Taxon', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Taxon',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }