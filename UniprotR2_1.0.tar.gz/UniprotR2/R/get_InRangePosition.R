#' @title get_InRangePosition
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * reference -- -
#'  * begin -- -
#'  * end -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_InRangePosition <- function(properties = list(objectProperties = list(unique = c("begin", "end", "reference"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(begin = "http://biohackathon.org/resource/faldo#begin", end = "http://biohackathon.org/resource/faldo#end", reference = "http://biohackathon.org/resource/faldo#reference")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(objectProperties = list(unique = c("begin", "end", "reference")))
   sparql <- makeSparql(propDict[flatProps],'InRangePosition', 'http://biohackathon.org/resource/faldo#InRangePosition', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('InRangePosition',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }