#' @title get_Enzyme
#' @description A specific catalytic activity, defined by the Enzyme Commission of the Nomenclature Committee of the International Union of Biochemistry and Molecular Biology (IUBMB).
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * obsolete -- True if this resource has been replaced or deleted.
#'  * replacedBy -- A resource that replaces this resource.
#'  * activity -- The catalytic activity of an enzyme.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * replaces -- A resource that is replaced by this resource.
#'  * broaderTransitive -- -
#'  * altLabel -- -
#'  * prefLabel -- -
#'  * narrowerTransitive -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Enzyme <- function(properties = list(dataProperties = list(unique = c("prefLabel", "obsolete"), nonunique = c("rdfs_comment", "altLabel")), objectProperties = list(unique = "broaderTransitive", nonunique = c("citation", "replaces", "rdfs_subClassOf", "replacedBy", "narrowerTransitive", "activity"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", obsolete = "http://purl.uniprot.org/core/obsolete", rdfs_comment = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", broaderTransitive = "http://www.w3.org/2004/02/skos/core#broaderTransitive", citation = "http://purl.uniprot.org/core/citation", replaces = "http://purl.uniprot.org/core/replaces", rdfs_subClassOf = "rdfs:subClassOf", replacedBy = "http://purl.uniprot.org/core/replacedBy", narrowerTransitive = "http://www.w3.org/2004/02/skos/core#narrowerTransitive", 
    activity = "http://purl.uniprot.org/core/activity")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("prefLabel", "obsolete"), nonunique = c("rdfs_comment", "altLabel")), objectProperties = list(unique = "broaderTransitive", nonunique = c("citation", "replaces", "rdfs_subClassOf", "replacedBy", "narrowerTransitive", "activity")))
   sparql <- makeSparql(propDict[flatProps],'Enzyme', 'http://purl.uniprot.org/core/Enzyme', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Enzyme',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }