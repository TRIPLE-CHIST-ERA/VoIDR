#' @title get_rdfs_Datatype
#' @description get_rdfs_Datatype
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_rdfs_Datatype <- function(properties = list(objectProperties = list(unique = "oneOf")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(oneOf = "http://www.w3.org/2002/07/owl#oneOf")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(objectProperties = list(unique = "oneOf"))
   sparql <- makeSparql(propDict[flatProps],'rdfs_Datatype', 'rdfs:Datatype', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('rdfs_Datatype',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }