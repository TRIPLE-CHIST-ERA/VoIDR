#' @title get_Zinc_Finger_Annotation
#' @description get_Zinc_Finger_Annotation
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Zinc_Finger_Annotation <- function(properties = list(dataProperties = list(nonunique = "rdfs_comment"), objectProperties = list(nonunique = "range")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_comment = "rdfs:comment", range = "http://purl.uniprot.org/core/range")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(nonunique = "rdfs_comment"), objectProperties = list(nonunique = "range"))
   sparql <- makeSparql(propDict[flatProps],'Zinc_Finger_Annotation', 'http://purl.uniprot.org/core/Zinc_Finger_Annotation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Zinc_Finger_Annotation',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }