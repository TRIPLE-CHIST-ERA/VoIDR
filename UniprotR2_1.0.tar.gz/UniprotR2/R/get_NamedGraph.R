#' @title get_NamedGraph
#' @description get_NamedGraph
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_NamedGraph <- function(properties = list(objectProperties = list(unique = c("graph", "name"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(graph = "http://www.w3.org/ns/sparql-service-description#graph", name = "http://www.w3.org/ns/sparql-service-description#name")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(objectProperties = list(unique = c("graph", "name")))
   sparql <- makeSparql(propDict[flatProps],'NamedGraph', 'http://www.w3.org/ns/sparql-service-description#NamedGraph', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('NamedGraph',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }