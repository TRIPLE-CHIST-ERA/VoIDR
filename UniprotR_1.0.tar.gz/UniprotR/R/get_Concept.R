#' @title get_Concept
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * altLabel -- -
#'  * prefLabel -- -
#'  * narrower -- -
#'  * category -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Concept <- function(properties = list(literalProperties = list(nonunique = c("rdfs:comment", "altLabel", "prefLabel")), iriProperties = list(nonunique = c("rdfs:seeAlso", "rdfs:subClassOf", "narrower", "category"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(`rdfs:comment` = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", `rdfs:seeAlso` = "rdfs:seeAlso", `rdfs:subClassOf` = "rdfs:subClassOf", narrower = "http://www.w3.org/2004/02/skos/core#narrower", category = "http://purl.uniprot.org/core/category")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Concept', 'http://purl.uniprot.org/core/Concept', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }