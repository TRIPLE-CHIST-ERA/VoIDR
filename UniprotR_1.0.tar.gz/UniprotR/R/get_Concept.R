#' @title get_Concept
#' @description A concept used to classify resources.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * category -- category
#'  * altLabel -- -
#'  * narrower -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Concept <- function(properties = list(dataProperties = list(unique = "prefLabel", nonunique = c("rdfs_comment", "altLabel")), objectProperties = list(unique = "category", nonunique = c("rdfs_seeAlso", "rdfs_subClassOf", "narrower"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", rdfs_comment = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", category = "http://purl.uniprot.org/core/category", rdfs_seeAlso = "rdfs:seeAlso", rdfs_subClassOf = "rdfs:subClassOf", narrower = "http://www.w3.org/2004/02/skos/core#narrower")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = "prefLabel", nonunique = c("rdfs_comment", "altLabel")), objectProperties = list(unique = "category", nonunique = c("rdfs_seeAlso", "rdfs_subClassOf", "narrower")))
   sparql <- makeSparql(propDict[flatProps],'Concept', 'http://purl.uniprot.org/core/Concept', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Concept',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }