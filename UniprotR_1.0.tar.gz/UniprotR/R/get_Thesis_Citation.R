#' @title get_Thesis_Citation
#' @description A Ph.D. thesis.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * author -- The author of a publication.
#'  * institution -- The institution at which a thesis was written.
#'  * place -- The place where a publication was published. This usually includes a country name.
#'  * title -- The title of a publication.
#'  * date -- date
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Thesis_Citation <- function(properties = c("author", "date", "institution", "place", "title"), limit = 1000){
    propDict <- list()
    propDict[c("author", "date", "institution", "place", "title")] <- c("http://purl.uniprot.org/core/author", "http://purl.uniprot.org/core/date", "http://purl.uniprot.org/core/institution", "http://purl.uniprot.org/core/place", "http://purl.uniprot.org/core/title")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Thesis_Citation a <',"http://purl.uniprot.org/core/Thesis_Citation",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Thesis_Citation ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }