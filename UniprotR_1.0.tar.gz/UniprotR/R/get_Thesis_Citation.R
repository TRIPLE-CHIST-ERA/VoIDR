#' @title get_Thesis_Citation
#' @description A Ph.D. thesis.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * author -- The author of a publication.
#'  * date -- date
#'  * institution -- The institution at which a thesis was written.
#'  * place -- The place where a publication was published. This usually includes a country name.
#'  * title -- The title of a publication.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Thesis_Citation <- function(properties = list(dataProperties = list(unique = c("date", "institution", "place", "title"), nonunique = "author")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(date = "http://purl.uniprot.org/core/date", institution = "http://purl.uniprot.org/core/institution", place = "http://purl.uniprot.org/core/place", title = "http://purl.uniprot.org/core/title", author = "http://purl.uniprot.org/core/author")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("date", "institution", "place", "title"), nonunique = "author"))
   sparql <- makeSparql(propDict[flatProps],'Thesis_Citation', 'http://purl.uniprot.org/core/Thesis_Citation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Thesis_Citation',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }