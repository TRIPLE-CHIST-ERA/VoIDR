#' @title get_OneOfPosition
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * possiblePosition -- -
#'  * reference -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_OneOfPosition <- function(properties = list(iriProperties = list(unique = "possiblePosition", nonunique = "reference")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(possiblePosition = "http://biohackathon.org/resource/faldo#possiblePosition", reference = "http://biohackathon.org/resource/faldo#reference")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(iriProperties = list(unique = "possiblePosition", nonunique = "reference"))
   sparql <- makeSparql(propDict[flatProps],'OneOfPosition', 'http://biohackathon.org/resource/faldo#OneOfPosition', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('OneOfPosition',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }