#' @title get_Structured_Name
#' @description A resource that holds a set of the known names for this protein together.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * allergenName -- See http://www.expasy.org/cgi-bin/lists?allergen.txt
#'  * cdAntigenName -- A name from the Human Cell Differentiation Molecules (HCDM) nomenclature.
#'  * ecName -- The ecName is the enzyme classification associated with a structured name of the protein. Proteins are often named after their enzymatic activity but can have more than one activity leading to multiple names.
#'  * fullName -- The full name.
#'  * internationalNonproprietaryName -- The international nonproprietary name: A generic name for a pharmaceutical substance or active pharmaceutical ingredient that is globally recognized and is a public property.
#'  * shortName -- An abbreviation of the full name or an acronym.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Structured_Name <- function(properties = list(dataProperties = list(unique = c("allergenName", "cdAntigenName", "fullName", "internationalNonproprietaryName"), nonunique = c("ecName", "shortName"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(allergenName = "http://purl.uniprot.org/core/allergenName", cdAntigenName = "http://purl.uniprot.org/core/cdAntigenName", fullName = "http://purl.uniprot.org/core/fullName", internationalNonproprietaryName = "http://purl.uniprot.org/core/internationalNonproprietaryName", ecName = "http://purl.uniprot.org/core/ecName", shortName = "http://purl.uniprot.org/core/shortName")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("allergenName", "cdAntigenName", "fullName", "internationalNonproprietaryName"), nonunique = c("ecName", "shortName")))
   sparql <- makeSparql(propDict[flatProps],'Structured_Name', 'http://purl.uniprot.org/core/Structured_Name', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Structured_Name',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }