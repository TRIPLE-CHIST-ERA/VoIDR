#' @title get_Structured_Name
#' @description A resource that holds a set of the known names for this protein together.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * structuredNameType -- All names of the protein, from commonly used to obsolete, to used in the literature..
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_Structured_Name <- function(properties = c("structuredNameType"), limit = 10000){
    propDict <- list()
    propDict[c("structuredNameType")] <- c("http://purl.uniprot.org/core/structuredNameType")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Structured_Name a <',"http://purl.uniprot.org/core/Structured_Name",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Structured_Name ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }