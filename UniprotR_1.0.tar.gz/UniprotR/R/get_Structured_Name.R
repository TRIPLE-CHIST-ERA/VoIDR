#' @title get_Structured_Name
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * internationalNonproprietaryName -- -
#'  * allergenName -- -
#'  * cdAntigenName -- -
#'  * ecName -- -
#'  * fullName -- -
#'  * shortName -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Structured_Name <- function(properties = list(literalProperties = list(unique = "internationalNonproprietaryName", nonunique = c("allergenName", "cdAntigenName", "ecName", "fullName", "shortName"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(internationalNonproprietaryName = "http://purl.uniprot.org/core/internationalNonproprietaryName", allergenName = "http://purl.uniprot.org/core/allergenName", cdAntigenName = "http://purl.uniprot.org/core/cdAntigenName", ecName = "http://purl.uniprot.org/core/ecName", fullName = "http://purl.uniprot.org/core/fullName", shortName = "http://purl.uniprot.org/core/shortName")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(unique = "internationalNonproprietaryName", nonunique = c("allergenName", "cdAntigenName", "ecName", "fullName", "shortName")))
   sparql <- makeSparql(propDict[flatProps],'Structured_Name', 'http://purl.uniprot.org/core/Structured_Name', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Structured_Name',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }