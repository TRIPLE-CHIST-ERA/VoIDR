#' @title get_Part
#' @description Description of a part of a protein.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * alternativeName -- A synonym of the recommended name.
#'  * recommendedName -- The name recommended by the UniProt consortium.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Part <- function(properties = list(objectProperties = list(unique = "recommendedName", nonunique = "alternativeName")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(recommendedName = "http://purl.uniprot.org/core/recommendedName", alternativeName = "http://purl.uniprot.org/core/alternativeName")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(objectProperties = list(unique = "recommendedName", nonunique = "alternativeName"))
   sparql <- makeSparql(propDict[flatProps],'Part', 'http://purl.uniprot.org/core/Part', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Part',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }