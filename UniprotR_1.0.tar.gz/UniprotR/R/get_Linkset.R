#' @title get_Linkset
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * triples -- -
#'  * objectsTarget -- -
#'  * subjectsTarget -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Linkset <- function(properties = list(literalProperties = list(nonunique = "triples"), iriProperties = list(nonunique = c("objectsTarget", "subjectsTarget"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(triples = "http://rdfs.org/ns/void#triples", objectsTarget = "http://rdfs.org/ns/void#objectsTarget", subjectsTarget = "http://rdfs.org/ns/void#subjectsTarget")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Linkset', 'http://rdfs.org/ns/void#Linkset', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }