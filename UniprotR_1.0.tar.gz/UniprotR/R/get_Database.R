#' @title get_Database
#' @description Metadata for a life science database.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * linkIsExplicit -- True if the Database is linked by an explicit action to UniProt, false if it is done using a simple hardcoded rule.
#'  * urlTemplate -- An string template that can be used to figure out from the database id what html page talks about it.
#'  * category -- category
#'  * abbreviation -- -
#'  * identifier -- -
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_Database <- function(properties = c("abbreviation", "category", "rdfs:comment", "identifier", "rdfs:label", "linkIsExplicit", "urlTemplate", "citation"), limit = 10000){
    propDict <- list()
    propDict[c("abbreviation", "category", "rdfs:comment", "identifier", "rdfs:label", "linkIsExplicit", "urlTemplate", "citation")] <- c("http://purl.uniprot.org/core/abbreviation", "http://purl.uniprot.org/core/category", "rdfs:comment", "http://purl.org/dc/terms/identifier", "rdfs:label", "http://purl.uniprot.org/core/linkIsExplicit", "http://purl.uniprot.org/core/urlTemplate", "http://purl.uniprot.org/core/citation")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Database a <',"http://purl.uniprot.org/core/Database",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Database ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }