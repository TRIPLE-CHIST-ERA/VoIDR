#' @title get_Database
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * abbreviation -- -
#'  * identifier -- -
#'  * category -- -
#'  * linkIsExplicit -- -
#'  * urlTemplate -- -
#'  * citation -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Database <- function(properties = list(literalProperties = list(unique = "abbreviation", nonunique = c("identifier", "rdfs_comment", "rdfs_label", "category", "linkIsExplicit", "urlTemplate")), iriProperties = list(nonunique = "citation")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(abbreviation = "http://purl.uniprot.org/core/abbreviation", identifier = "http://purl.org/dc/terms/identifier", rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label", category = "http://purl.uniprot.org/core/category", linkIsExplicit = "http://purl.uniprot.org/core/linkIsExplicit", urlTemplate = "http://purl.uniprot.org/core/urlTemplate", citation = "http://purl.uniprot.org/core/citation")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(unique = "abbreviation", nonunique = c("identifier", "rdfs_comment", "rdfs_label", "category", "linkIsExplicit", "urlTemplate")), iriProperties = list(nonunique = "citation"))
   sparql <- makeSparql(propDict[flatProps],'Database', 'http://purl.uniprot.org/core/Database', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Database',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }