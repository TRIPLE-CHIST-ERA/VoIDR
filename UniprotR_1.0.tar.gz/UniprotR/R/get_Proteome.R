#' @title get_Proteome
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * modified -- -
#'  * exclusionReason -- -
#'  * strain -- -
#'  * has_score -- -
#'  * citation -- -
#'  * closeMatch -- -
#'  * panproteome -- -
#'  * redundantTo -- -
#'  * narrower -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Proteome <- function(properties = list(literalProperties = list(nonunique = c("rdfs:comment", "modified", "exclusionReason")), iriProperties = list(unique = c("strain", "has_score"), nonunique = c("citation", "closeMatch", "panproteome", "redundantTo", "narrower"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(`rdfs:comment` = "rdfs:comment", modified = "http://purl.org/dc/terms/modified", exclusionReason = "http://purl.uniprot.org/core/exclusionReason", strain = "http://purl.uniprot.org/core/strain", has_score = "http://busco.ezlab.org/schema#has_score", citation = "http://purl.uniprot.org/core/citation", closeMatch = "http://www.w3.org/2004/02/skos/core#closeMatch", panproteome = "http://purl.uniprot.org/core/panproteome", redundantTo = "http://purl.uniprot.org/core/redundantTo", narrower = "http://www.w3.org/2004/02/skos/core#narrower")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Proteome', 'http://purl.uniprot.org/core/Proteome', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }