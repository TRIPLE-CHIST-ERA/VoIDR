#' @title get_Proteome
#' @description Description of a proteome.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * exclusionReason -- Indicates why the proteins of an Proteome where excluded from UniProtKB.
#'  * panproteome -- The current pan proteome sequences are derived from the reference proteome clusters (75% proteome similarity for Fungus and 55% proteome similarity for Archaea and Bacteria). A reference proteome cluster is also known as a representative proteome group (RPG) (Chen et al., 2011). A RPG contains similar proteomes calculated based on their co-membership in UniRef50 clusters. For each non-singleton reference proteome cluster, a pan proteome is a set of sequences consisting of all the sequences in the reference proteome, plus the addition of unique protein sequences that are found in other species or strains of the cluster but not in the reference proteome. These additional sequences are identified using UniRef50 membership.
#'  * redundantTo -- Indicates which proteome this proteome is redundant to.
#'  * strain -- strain
#'  * narrower -- -
#'  * closeMatch -- -
#'  * has_score -- -
#'  * modified -- -
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_Proteome <- function(properties = c("rdfs:comment", "exclusionReason", "modified", "citation", "redundantTo", "panproteome", "narrower", "closeMatch", "has_score", "strain"), limit = 10000){
    propDict <- list()
    propDict[c("rdfs:comment", "exclusionReason", "modified", "citation", "redundantTo", "panproteome", "narrower", "closeMatch", "has_score", "strain")] <- c("rdfs:comment", "http://purl.uniprot.org/core/exclusionReason", "http://purl.org/dc/terms/modified", "http://purl.uniprot.org/core/citation", "http://purl.uniprot.org/core/redundantTo", "http://purl.uniprot.org/core/panproteome", "http://www.w3.org/2004/02/skos/core#narrower", "http://www.w3.org/2004/02/skos/core#closeMatch", "http://busco.ezlab.org/schema#has_score", "http://purl.uniprot.org/core/strain")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Proteome a <',"http://purl.uniprot.org/core/Proteome",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Proteome ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }