#' @title get_Proteome
#' @description Description of a proteome.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * has_score -- -
#'  * modified -- -
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * exclusionReason -- Indicates why the proteins of an Proteome where excluded from UniProtKB.
#'  * panproteome -- The current pan proteome sequences are derived from the reference proteome clusters (75% proteome similarity for Fungus and 55% proteome similarity for Archaea and Bacteria). A reference proteome cluster is also known as a representative proteome group (RPG) (Chen et al., 2011). A RPG contains similar proteomes calculated based on their co-membership in UniRef50 clusters. For each non-singleton reference proteome cluster, a pan proteome is a set of sequences consisting of all the sequences in the reference proteome, plus the addition of unique protein sequences that are found in other species or strains of the cluster but not in the reference proteome. These additional sequences are identified using UniRef50 membership.
#'  * redundantTo -- Indicates which proteome this proteome is redundant to.
#'  * strain -- strain
#'  * closeMatch -- -
#'  * narrower -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Proteome <- function(properties = list(dataProperties = list(unique = "modified", nonunique = c("rdfs_comment", "exclusionReason")), objectProperties = list(unique = c("closeMatch", "has_score", "panproteome", "redundantTo"), nonunique = c("citation", "strain", "narrower"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(modified = "http://purl.org/dc/terms/modified", rdfs_comment = "rdfs:comment", exclusionReason = "http://purl.uniprot.org/core/exclusionReason", closeMatch = "http://www.w3.org/2004/02/skos/core#closeMatch", has_score = "http://busco.ezlab.org/schema#has_score", panproteome = "http://purl.uniprot.org/core/panproteome", redundantTo = "http://purl.uniprot.org/core/redundantTo", citation = "http://purl.uniprot.org/core/citation", strain = "http://purl.uniprot.org/core/strain", narrower = "http://www.w3.org/2004/02/skos/core#narrower")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = "modified", nonunique = c("rdfs_comment", "exclusionReason")), objectProperties = list(unique = c("closeMatch", "has_score", "panproteome", "redundantTo"), nonunique = c("citation", "strain", "narrower")))
   sparql <- makeSparql(propDict[flatProps],'Proteome', 'http://purl.uniprot.org/core/Proteome', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Proteome',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }