#' @title get_DatatypeProperty
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * deprecated -- -
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_DatatypeProperty <- function(properties = c("rdfs:comment", "deprecated", "rdfs:label", "rdfs:domain", "rdfs:isDefinedBy", "rdfs:range", "rdfs:subPropertyOf"), limit = 10000){
    propDict <- list()
    propDict[c("rdfs:comment", "deprecated", "rdfs:label", "rdfs:domain", "rdfs:isDefinedBy", "rdfs:range", "rdfs:subPropertyOf")] <- c("rdfs:comment", "http://www.w3.org/2002/07/owl#deprecated", "rdfs:label", "rdfs:domain", "rdfs:isDefinedBy", "rdfs:range", "rdfs:subPropertyOf")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?DatatypeProperty a <',"http://www.w3.org/2002/07/owl#DatatypeProperty",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?DatatypeProperty ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }