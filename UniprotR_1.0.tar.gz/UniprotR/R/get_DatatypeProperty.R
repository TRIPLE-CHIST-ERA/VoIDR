#' @title get_DatatypeProperty
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * deprecated -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_DatatypeProperty <- function(properties = list(dataProperties = list(unique = "deprecated", nonunique = c("rdfs_comment", "rdfs_label")), objectProperties = list(unique = c("rdfs_subPropertyOf", "rdfs_domain", "rdfs_isDefinedBy", "rdfs_range"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(deprecated = "http://www.w3.org/2002/07/owl#deprecated", rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label", rdfs_subPropertyOf = "rdfs:subPropertyOf", rdfs_domain = "rdfs:domain", rdfs_isDefinedBy = "rdfs:isDefinedBy", rdfs_range = "rdfs:range")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = "deprecated", nonunique = c("rdfs_comment", "rdfs_label")), objectProperties = list(unique = c("rdfs_subPropertyOf", "rdfs_domain", "rdfs_isDefinedBy", "rdfs_range")))
   sparql <- makeSparql(propDict[flatProps],'DatatypeProperty', 'http://www.w3.org/2002/07/owl#DatatypeProperty', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('DatatypeProperty',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }