#' @title get_Intramembrane_Annotation
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * range -- -
#'  * sequence -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Intramembrane_Annotation <- function(properties = list(literalProperties = list(nonunique = "rdfs:comment"), iriProperties = list(nonunique = c("range", "sequence"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(`rdfs:comment` = "rdfs:comment", range = "http://purl.uniprot.org/core/range", sequence = "http://purl.uniprot.org/core/sequence")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Intramembrane_Annotation', 'http://purl.uniprot.org/core/Intramembrane_Annotation', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }