#' @title get_Orientation
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * alias -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Orientation <- function(properties = list(literalProperties = list(unique = "alias", nonunique = c("rdfs:comment", "prefLabel"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(alias = "http://purl.uniprot.org/core/alias", `rdfs:comment` = "rdfs:comment", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Orientation', 'http://purl.uniprot.org/core/Orientation', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }