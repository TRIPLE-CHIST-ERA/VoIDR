#' @title get_Pathway
#' @description A hierarchical discription of a metabolic pathway.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * narrower -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Pathway <- function(properties = c("rdfs:label", "rdfs:subClassOf", "narrower"), limit = 1000){
    propDict <- list()
    propDict[c("rdfs:label", "rdfs:subClassOf", "narrower")] <- c("rdfs:label", "rdfs:subClassOf", "http://www.w3.org/2004/02/skos/core#narrower")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Pathway a <',"http://purl.uniprot.org/core/Pathway",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Pathway ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }