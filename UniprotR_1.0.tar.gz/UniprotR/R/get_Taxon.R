#' @title get_Taxon
#' @description An element of a taxonomy for classifying life forms.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * mnemonic -- A rememberable string that can be used to find entries, not a stable identifier!
#'  * mnemonic -- A easy to remember identifier for a UniProtKB entry, but it is not a stable identifier and should not be used by programs to identify entries.
#'  * obsolete -- True if this resource has been replaced or deleted.
#'  * partOfLineage -- True for taxa that can appear as part of an organism's non abbreviated lineage. In the flatfile and XML views of an UniProt entry (as well as at INSDC) only these taxonomic nodes are shown.
#'  * replacedBy -- A resource that replaces this resource.
#'  * replaces -- A resource that is replaced by this resource.
#'  * commonName -- common name
#'  * host -- host
#'  * otherName -- other name
#'  * scientificName -- scientific name
#'  * strain -- strain
#'  * synonym -- synonym
#'  * narrowerTransitive -- -
#'  * depiction -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Taxon <- function(properties = c("commonName", "mnemonic", "obsolete", "otherName", "partOfLineage", "scientificName", "synonym", "depiction", "host", "narrowerTransitive", "replacedBy", "replaces", "strain", "rdfs:subClassOf"), limit = 1000){
    propDict <- list()
    propDict[c("commonName", "mnemonic", "obsolete", "otherName", "partOfLineage", "scientificName", "synonym", "depiction", "host", "narrowerTransitive", "replacedBy", "replaces", "strain", "rdfs:subClassOf")] <- c("http://purl.uniprot.org/core/commonName", "http://purl.uniprot.org/core/mnemonic", "http://purl.uniprot.org/core/obsolete", "http://purl.uniprot.org/core/otherName", "http://purl.uniprot.org/core/partOfLineage", "http://purl.uniprot.org/core/scientificName", "http://purl.uniprot.org/core/synonym", "http://xmlns.com/foaf/0.1/depiction", "http://purl.uniprot.org/core/host", "http://www.w3.org/2004/02/skos/core#narrowerTransitive", "http://purl.uniprot.org/core/replacedBy", "http://purl.uniprot.org/core/replaces", "http://purl.uniprot.org/core/strain", "rdfs:subClassOf")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Taxon a <',"http://purl.uniprot.org/core/Taxon",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Taxon ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }