#' @title get_Taxon
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * mnemonic -- -
#'  * obsolete -- -
#'  * commonName -- -
#'  * otherName -- -
#'  * partOfLineage -- -
#'  * scientificName -- -
#'  * synonym -- -
#'  * strain -- -
#'  * narrowerTransitive -- -
#'  * replaces -- -
#'  * replacedBy -- -
#'  * host -- -
#'  * depiction -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Taxon <- function(properties = list(literalProperties = list(nonunique = c("mnemonic", "obsolete", "commonName", "otherName", "partOfLineage", "scientificName", "synonym")), iriProperties = list(unique = c("strain", "narrowerTransitive"), nonunique = c("replaces", "rdfs:subClassOf", "replacedBy", "host", "depiction"))), limit = 1000){
   iriProps <- list(literalProperties = list(nonunique = c("http://purl.uniprot.org/core/mnemonic", "http://purl.uniprot.org/core/obsolete", "http://purl.uniprot.org/core/commonName", "http://purl.uniprot.org/core/otherName", "http://purl.uniprot.org/core/partOfLineage", "http://purl.uniprot.org/core/scientificName", "http://purl.uniprot.org/core/synonym")), iriProperties = list(unique = c("http://purl.uniprot.org/core/strain", "http://www.w3.org/2004/02/skos/core#narrowerTransitive"), nonunique = c("http://purl.uniprot.org/core/replaces", 
"rdfs:subClassOf", "http://purl.uniprot.org/core/replacedBy", "http://purl.uniprot.org/core/host", "http://xmlns.com/foaf/0.1/depiction")))
   sapply(names(properties), function(t){
    propType = properties[[t]]
    sapply(names(propType), function(card){
      propCard <- propType[[card]]
      propDict <- list()
      propDict[propCard] <- iriProps[[t]][[card]]
      propFilter <- paste(propDict[propCard], collapse='> <')
      sparql <- makeSparql(propFilter,'Taxon', 'http://purl.uniprot.org/core/Taxon', limit)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)
    }, simplify = FALSE)
   }, simplify = FALSE)

  }