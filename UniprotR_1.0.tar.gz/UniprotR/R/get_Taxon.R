#' @title get_Taxon
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * mnemonic -- -
#'  * obsolete -- -
#'  * commonName -- -
#'  * otherName -- -
#'  * partOfLineage -- -
#'  * scientificName -- -
#'  * synonym -- -
#'  * strain -- -
#'  * narrowerTransitive -- -
#'  * replaces -- -
#'  * replacedBy -- -
#'  * host -- -
#'  * depiction -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Taxon <- function(properties = list(literalProperties = list(nonunique = c("mnemonic", "obsolete", "commonName", "otherName", "partOfLineage", "scientificName", "synonym")), iriProperties = list(unique = c("strain", "narrowerTransitive"), nonunique = c("replaces", "rdfs:subClassOf", "replacedBy", "host", "depiction"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(mnemonic = "http://purl.uniprot.org/core/mnemonic", obsolete = "http://purl.uniprot.org/core/obsolete", commonName = "http://purl.uniprot.org/core/commonName", otherName = "http://purl.uniprot.org/core/otherName", partOfLineage = "http://purl.uniprot.org/core/partOfLineage", scientificName = "http://purl.uniprot.org/core/scientificName", synonym = "http://purl.uniprot.org/core/synonym", strain = "http://purl.uniprot.org/core/strain", narrowerTransitive = "http://www.w3.org/2004/02/skos/core#narrowerTransitive", 
    replaces = "http://purl.uniprot.org/core/replaces", `rdfs:subClassOf` = "rdfs:subClassOf", replacedBy = "http://purl.uniprot.org/core/replacedBy", host = "http://purl.uniprot.org/core/host", depiction = "http://xmlns.com/foaf/0.1/depiction")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Taxon', 'http://purl.uniprot.org/core/Taxon', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }