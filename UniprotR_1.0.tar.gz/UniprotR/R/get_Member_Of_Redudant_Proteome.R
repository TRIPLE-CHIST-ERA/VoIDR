#' @title get_Member_Of_Redudant_Proteome
#' @description This entry was obsoleted because its sequence belongs to a redundant protoeome
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * created -- The date a resource was created.
#'  * mnemonic -- A easy to remember identifier for a UniProtKB entry, but it is not a stable identifier and should not be used by programs to identify entries.
#'  * modified -- The date a resource was last modified.
#'  * obsolete -- True if this resource has been replaced or deleted.
#'  * reviewed -- Indicates whether a resource has been reviewed by a curator.
#'  * version -- version
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Member_Of_Redudant_Proteome <- function(properties = list(dataProperties = list(unique = c("created", "mnemonic", "modified", "reviewed", "version", "obsolete"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(created = "http://purl.uniprot.org/core/created", mnemonic = "http://purl.uniprot.org/core/mnemonic", modified = "http://purl.uniprot.org/core/modified", reviewed = "http://purl.uniprot.org/core/reviewed", version = "http://purl.uniprot.org/core/version", obsolete = "http://purl.uniprot.org/core/obsolete")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("created", "mnemonic", "modified", "reviewed", "version", "obsolete")))
   sparql <- makeSparql(propDict[flatProps],'Member_Of_Redudant_Proteome', 'http://purl.uniprot.org/core/Member_Of_Redudant_Proteome', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Member_Of_Redudant_Proteome',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }