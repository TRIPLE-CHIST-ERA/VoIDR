#' @title get_Restriction
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * minCardinality -- -
#'  * cardinality -- -
#'  * hasValue -- -
#'  * maxCardinality -- -
#'  * maxQualifiedCardinality -- -
#'  * qualifiedCardinality -- -
#'  * onProperty -- -
#'  * someValuesFrom -- -
#'  * allValuesFrom -- -
#'  * onClass -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Restriction <- function(properties = list(literalProperties = list(unique = "minCardinality", nonunique = c("cardinality", "hasValue", "maxCardinality", "maxQualifiedCardinality", "qualifiedCardinality")), iriProperties = list(nonunique = c("onProperty", "someValuesFrom", "allValuesFrom", "onClass"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(minCardinality = "http://www.w3.org/2002/07/owl#minCardinality", cardinality = "http://www.w3.org/2002/07/owl#cardinality", hasValue = "http://www.w3.org/2002/07/owl#hasValue", maxCardinality = "http://www.w3.org/2002/07/owl#maxCardinality", maxQualifiedCardinality = "http://www.w3.org/2002/07/owl#maxQualifiedCardinality", qualifiedCardinality = "http://www.w3.org/2002/07/owl#qualifiedCardinality", onProperty = "http://www.w3.org/2002/07/owl#onProperty", someValuesFrom = "http://www.w3.org/2002/07/owl#someValuesFrom", 
    allValuesFrom = "http://www.w3.org/2002/07/owl#allValuesFrom", onClass = "http://www.w3.org/2002/07/owl#onClass")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(unique = "minCardinality", nonunique = c("cardinality", "hasValue", "maxCardinality", "maxQualifiedCardinality", "qualifiedCardinality")), iriProperties = list(nonunique = c("onProperty", "someValuesFrom", "allValuesFrom", "onClass")))
   sparql <- makeSparql(propDict[flatProps],'Restriction', 'http://www.w3.org/2002/07/owl#Restriction', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Restriction',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }