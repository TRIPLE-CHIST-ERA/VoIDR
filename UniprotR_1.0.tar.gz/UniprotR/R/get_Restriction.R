#' @title get_Restriction
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * allValuesFrom -- -
#'  * cardinality -- -
#'  * hasValue -- -
#'  * maxCardinality -- -
#'  * maxQualifiedCardinality -- -
#'  * minCardinality -- -
#'  * onClass -- -
#'  * onProperty -- -
#'  * qualifiedCardinality -- -
#'  * someValuesFrom -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Restriction <- function(properties = c("cardinality", "hasValue", "maxCardinality", "maxQualifiedCardinality", "minCardinality", "qualifiedCardinality", "someValuesFrom", "onClass", "allValuesFrom", "onProperty"), limit = 1000){
    propDict <- list()
    propDict[c("cardinality", "hasValue", "maxCardinality", "maxQualifiedCardinality", "minCardinality", "qualifiedCardinality", "someValuesFrom", "onClass", "allValuesFrom", "onProperty")] <- c("http://www.w3.org/2002/07/owl#cardinality", "http://www.w3.org/2002/07/owl#hasValue", "http://www.w3.org/2002/07/owl#maxCardinality", "http://www.w3.org/2002/07/owl#maxQualifiedCardinality", "http://www.w3.org/2002/07/owl#minCardinality", "http://www.w3.org/2002/07/owl#qualifiedCardinality", "http://www.w3.org/2002/07/owl#someValuesFrom", "http://www.w3.org/2002/07/owl#onClass", "http://www.w3.org/2002/07/owl#allValuesFrom", "http://www.w3.org/2002/07/owl#onProperty")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Restriction a <',"http://www.w3.org/2002/07/owl#Restriction",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Restriction ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }