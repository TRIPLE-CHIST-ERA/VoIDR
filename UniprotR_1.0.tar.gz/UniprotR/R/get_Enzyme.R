#' @title get_Enzyme
#' @description A specific catalytic activity, defined by the Enzyme Commission of the Nomenclature Committee of the International Union of Biochemistry and Molecular Biology (IUBMB).
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * activity -- The catalytic activity of an enzyme.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * obsolete -- True if this resource has been replaced or deleted.
#'  * replacedBy -- A resource that replaces this resource.
#'  * replaces -- A resource that is replaced by this resource.
#'  * altLabel -- -
#'  * broaderTransitive -- -
#'  * narrowerTransitive -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Enzyme <- function(properties = list(dataProperties = list(unique = c("prefLabel", "obsolete"), nonunique = c("rdfs_comment", "altLabel")), objectProperties = list(unique = "broaderTransitive", nonunique = c("citation", "replaces", "rdfs_subClassOf", "replacedBy", "narrowerTransitive", "activity"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", obsolete = "http://purl.uniprot.org/core/obsolete", rdfs_comment = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", broaderTransitive = "http://www.w3.org/2004/02/skos/core#broaderTransitive", citation = "http://purl.uniprot.org/core/citation", replaces = "http://purl.uniprot.org/core/replaces", rdfs_subClassOf = "rdfs:subClassOf", replacedBy = "http://purl.uniprot.org/core/replacedBy", narrowerTransitive = "http://www.w3.org/2004/02/skos/core#narrowerTransitive", 
    activity = "http://purl.uniprot.org/core/activity")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("prefLabel", "obsolete"), nonunique = c("rdfs_comment", "altLabel")), objectProperties = list(unique = "broaderTransitive", nonunique = c("citation", "replaces", "rdfs_subClassOf", "replacedBy", "narrowerTransitive", "activity")))
   sparql <- makeSparql(propDict[flatProps],'Enzyme', 'http://purl.uniprot.org/core/Enzyme', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Enzyme',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }