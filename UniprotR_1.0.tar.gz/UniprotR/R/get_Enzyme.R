#' @title get_Enzyme
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * altLabel -- -
#'  * prefLabel -- -
#'  * obsolete -- -
#'  * narrowerTransitive -- -
#'  * activity -- -
#'  * citation -- -
#'  * replaces -- -
#'  * replacedBy -- -
#'  * broaderTransitive -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Enzyme <- function(properties = list(literalProperties = list(nonunique = c("rdfs:comment", "altLabel", "prefLabel", "obsolete")), iriProperties = list(unique = c("narrowerTransitive", "activity"), nonunique = c("citation", "replaces", "rdfs:subClassOf", "replacedBy", "broaderTransitive"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(`rdfs:comment` = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", obsolete = "http://purl.uniprot.org/core/obsolete", narrowerTransitive = "http://www.w3.org/2004/02/skos/core#narrowerTransitive", activity = "http://purl.uniprot.org/core/activity", citation = "http://purl.uniprot.org/core/citation", replaces = "http://purl.uniprot.org/core/replaces", `rdfs:subClassOf` = "rdfs:subClassOf", replacedBy = "http://purl.uniprot.org/core/replacedBy", 
    broaderTransitive = "http://www.w3.org/2004/02/skos/core#broaderTransitive")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Enzyme', 'http://purl.uniprot.org/core/Enzyme', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }