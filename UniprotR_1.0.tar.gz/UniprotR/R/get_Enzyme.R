#' @title get_Enzyme
#' @description A specific catalytic activity, defined by the Enzyme Commission of the Nomenclature Committee of the International Union of Biochemistry and Molecular Biology (IUBMB).
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * activity -- The catalytic activity of an enzyme.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * obsolete -- True if this resource has been replaced or deleted.
#'  * replacedBy -- A resource that replaces this resource.
#'  * replaces -- A resource that is replaced by this resource.
#'  * prefLabel -- -
#'  * altLabel -- -
#'  * broaderTransitive -- -
#'  * narrowerTransitive -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Enzyme <- function(properties = c("altLabel", "rdfs:comment", "obsolete", "prefLabel", "citation", "activity", "rdfs:subClassOf", "broaderTransitive", "replaces", "narrowerTransitive", "replacedBy"), limit = 1000){
    propDict <- list()
    propDict[c("altLabel", "rdfs:comment", "obsolete", "prefLabel", "citation", "activity", "rdfs:subClassOf", "broaderTransitive", "replaces", "narrowerTransitive", "replacedBy")] <- c("http://www.w3.org/2004/02/skos/core#altLabel", "rdfs:comment", "http://purl.uniprot.org/core/obsolete", "http://www.w3.org/2004/02/skos/core#prefLabel", "http://purl.uniprot.org/core/citation", "http://purl.uniprot.org/core/activity", "rdfs:subClassOf", "http://www.w3.org/2004/02/skos/core#broaderTransitive", "http://purl.uniprot.org/core/replaces", "http://www.w3.org/2004/02/skos/core#narrowerTransitive", "http://purl.uniprot.org/core/replacedBy")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Enzyme a <',"http://purl.uniprot.org/core/Enzyme",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Enzyme ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }