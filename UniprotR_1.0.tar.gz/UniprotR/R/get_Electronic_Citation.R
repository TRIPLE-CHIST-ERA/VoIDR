#' @title get_Electronic_Citation
#' @description An electronic publication.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * identifier -- -
#'  * author -- The author of a publication.
#'  * date -- date
#'  * locator -- locator
#'  * name -- name
#'  * title -- The title of a publication.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Electronic_Citation <- function(properties = list(dataProperties = list(unique = c("date", "locator", "title"), nonunique = c("identifier", "author", "name"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(date = "http://purl.uniprot.org/core/date", locator = "http://purl.uniprot.org/core/locator", title = "http://purl.uniprot.org/core/title", identifier = "http://purl.org/dc/terms/identifier", author = "http://purl.uniprot.org/core/author", name = "http://purl.uniprot.org/core/name")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("date", "locator", "title"), nonunique = c("identifier", "author", "name")))
   sparql <- makeSparql(propDict[flatProps],'Electronic_Citation', 'http://purl.uniprot.org/core/Electronic_Citation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Electronic_Citation',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }