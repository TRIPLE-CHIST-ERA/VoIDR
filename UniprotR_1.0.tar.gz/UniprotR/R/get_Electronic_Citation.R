#' @title get_Electronic_Citation
#' @description An electronic publication.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * author -- The author of a publication.
#'  * title -- The title of a publication.
#'  * date -- date
#'  * locator -- locator
#'  * name -- name
#'  * identifier -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Electronic_Citation <- function(properties = c("author", "date", "identifier", "locator", "name", "title"), limit = 1000){
    propDict <- list()
    propDict[c("author", "date", "identifier", "locator", "name", "title")] <- c("http://purl.uniprot.org/core/author", "http://purl.uniprot.org/core/date", "http://purl.org/dc/terms/identifier", "http://purl.uniprot.org/core/locator", "http://purl.uniprot.org/core/name", "http://purl.uniprot.org/core/title")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Electronic_Citation a <',"http://purl.uniprot.org/core/Electronic_Citation",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Electronic_Citation ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }