#' @title get_Structure_Resource
#' @description A resource that describes the 3D structure of a protein.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * resolution -- The resolution of an experiment, in Angstrom.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Structure_Resource <- function(properties = list(dataProperties = list(nonunique = "resolution")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(resolution = "http://purl.uniprot.org/core/resolution")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(nonunique = "resolution"))
   sparql <- makeSparql(propDict[flatProps],'Structure_Resource', 'http://purl.uniprot.org/core/Structure_Resource', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Structure_Resource',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }