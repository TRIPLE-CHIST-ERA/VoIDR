#' @title get_Thing
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Thing <- function(properties = list(literalProperties = list(nonunique = c("rdfs_comment", "rdfs_label")), iriProperties = list(nonunique = "rdfs_isDefinedBy")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label", rdfs_isDefinedBy = "rdfs:isDefinedBy")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = c("rdfs_comment", "rdfs_label")), iriProperties = list(nonunique = "rdfs_isDefinedBy"))
   sparql <- makeSparql(propDict[flatProps],'Thing', 'http://www.w3.org/2002/07/owl#Thing', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Thing',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }