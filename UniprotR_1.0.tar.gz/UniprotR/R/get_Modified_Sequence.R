#' @title get_Modified_Sequence
#' @description Modified Sequence
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * basedOn -- The sequence on which the description of a modified sequence is based.
#'  * modification -- A modification of a sequence.
#'  * name -- name
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Modified_Sequence <- function(properties = c("name", "rdf:value", "basedOn", "modification"), limit = 1000){
    propDict <- list()
    propDict[c("name", "rdf:value", "basedOn", "modification")] <- c("http://purl.uniprot.org/core/name", "rdf:value", "http://purl.uniprot.org/core/basedOn", "http://purl.uniprot.org/core/modification")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Modified_Sequence a <',"http://purl.uniprot.org/core/Modified_Sequence",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Modified_Sequence ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }