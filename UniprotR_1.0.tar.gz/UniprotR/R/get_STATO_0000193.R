#' @title get_STATO_0000193
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_STATO_0000193 <- function(properties = list(literalProperties = list(nonunique = c("rdfs_comment", "rdfs_label"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = c("rdfs_comment", "rdfs_label")))
   sparql <- makeSparql(propDict[flatProps],'STATO_0000193', 'http://purl.obolibrary.org/obo/STATO_0000193', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('STATO_0000193',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }