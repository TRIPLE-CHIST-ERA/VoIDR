#' @title get_Catalytic_Activity_Annotation
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * catalyticActivity -- -
#'  * sequence -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Catalytic_Activity_Annotation <- function(properties = list(iriProperties = list(nonunique = c("catalyticActivity", "sequence"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(catalyticActivity = "http://purl.uniprot.org/core/catalyticActivity", sequence = "http://purl.uniprot.org/core/sequence")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(iriProperties = list(nonunique = c("catalyticActivity", "sequence")))
   sparql <- makeSparql(propDict[flatProps],'Catalytic_Activity_Annotation', 'http://purl.uniprot.org/core/Catalytic_Activity_Annotation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Catalytic_Activity_Annotation',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }