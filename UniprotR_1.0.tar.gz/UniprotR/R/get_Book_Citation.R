#' @title get_Book_Citation
#' @description A chapter from a book.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * author -- The author of a publication.
#'  * editor -- The editor of a publication.
#'  * group -- The group or consortium that authored a publication.
#'  * pages -- The first and last page for a chapter or article.
#'  * place -- The place where a publication was published. This usually includes a country name.
#'  * publisher -- The publisher of a book.
#'  * title -- The title of a publication.
#'  * volume -- The volume a publication is part of.
#'  * date -- date
#'  * name -- name
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_Book_Citation <- function(properties = c("author", "date", "editor", "group", "name", "pages", "place", "publisher", "title", "volume"), limit = 10000){
    propDict <- list()
    propDict[c("author", "date", "editor", "group", "name", "pages", "place", "publisher", "title", "volume")] <- c("http://purl.uniprot.org/core/author", "http://purl.uniprot.org/core/date", "http://purl.uniprot.org/core/editor", "http://purl.uniprot.org/core/group", "http://purl.uniprot.org/core/name", "http://purl.uniprot.org/core/pages", "http://purl.uniprot.org/core/place", "http://purl.uniprot.org/core/publisher", "http://purl.uniprot.org/core/title", "http://purl.uniprot.org/core/volume")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Book_Citation a <',"http://purl.uniprot.org/core/Book_Citation",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Book_Citation ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }