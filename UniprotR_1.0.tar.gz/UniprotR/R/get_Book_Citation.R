#' @title get_Book_Citation
#' @description A chapter from a book.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * identifier -- -
#'  * author -- The author of a publication.
#'  * date -- date
#'  * editor -- The editor of a publication.
#'  * group -- The group or consortium that authored a publication.
#'  * name -- name
#'  * pages -- The first and last page for a chapter or article.
#'  * place -- The place where a publication was published. This usually includes a country name.
#'  * publisher -- The publisher of a book.
#'  * title -- The title of a publication.
#'  * volume -- The volume a publication is part of.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Book_Citation <- function(properties = list(dataProperties = list(unique = c("date", "pages", "place", "publisher", "title", "volume"), nonunique = c("identifier", "author", "editor", "group", "name"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(date = "http://purl.uniprot.org/core/date", pages = "http://purl.uniprot.org/core/pages", place = "http://purl.uniprot.org/core/place", publisher = "http://purl.uniprot.org/core/publisher", title = "http://purl.uniprot.org/core/title", volume = "http://purl.uniprot.org/core/volume", identifier = "http://purl.org/dc/terms/identifier", author = "http://purl.uniprot.org/core/author", editor = "http://purl.uniprot.org/core/editor", group = "http://purl.uniprot.org/core/group", name = "http://purl.uniprot.org/core/name")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("date", "pages", "place", "publisher", "title", "volume"), nonunique = c("identifier", "author", "editor", "group", "name")))
   sparql <- makeSparql(propDict[flatProps],'Book_Citation', 'http://purl.uniprot.org/core/Book_Citation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Book_Citation',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }