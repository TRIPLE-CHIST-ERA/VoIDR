#' @title get_Book_Citation
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * identifier -- -
#'  * author -- -
#'  * date -- -
#'  * editor -- -
#'  * group -- -
#'  * name -- -
#'  * pages -- -
#'  * place -- -
#'  * publisher -- -
#'  * title -- -
#'  * volume -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Book_Citation <- function(properties = list(literalProperties = list(nonunique = c("identifier", "author", "date", "editor", "group", "name", "pages", "place", "publisher", "title", "volume"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(identifier = "http://purl.org/dc/terms/identifier", author = "http://purl.uniprot.org/core/author", date = "http://purl.uniprot.org/core/date", editor = "http://purl.uniprot.org/core/editor", group = "http://purl.uniprot.org/core/group", name = "http://purl.uniprot.org/core/name", pages = "http://purl.uniprot.org/core/pages", place = "http://purl.uniprot.org/core/place", publisher = "http://purl.uniprot.org/core/publisher", title = "http://purl.uniprot.org/core/title", volume = "http://purl.uniprot.org/core/volume")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = c("identifier", "author", "date", "editor", "group", "name", "pages", "place", "publisher", "title", "volume")))
   sparql <- makeSparql(propDict[flatProps],'Book_Citation', 'http://purl.uniprot.org/core/Book_Citation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Book_Citation',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }