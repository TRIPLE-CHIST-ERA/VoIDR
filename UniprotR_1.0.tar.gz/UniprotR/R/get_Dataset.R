#' @title get_Dataset
#' @description get_Dataset
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * datatypePartition -- -
#'  * classPartition -- -
#'  * entities -- -
#'  * propertyPartition -- -
#'  * triples -- -
#'  * defaultGraph -- -
#'  * namedGraph -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Dataset <- function(properties = list(dataProperties = list(unique = c("entities", "triples")), objectProperties = list(unique = "defaultGraph", nonunique = c("datatypePartition", "classPartition", "propertyPartition", "namedGraph"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(entities = "http://rdfs.org/ns/void#entities", triples = "http://rdfs.org/ns/void#triples", defaultGraph = "http://www.w3.org/ns/sparql-service-description#defaultGraph", datatypePartition = "http://ldf.fi/void-ext#datatypePartition", classPartition = "http://rdfs.org/ns/void#classPartition", propertyPartition = "http://rdfs.org/ns/void#propertyPartition", namedGraph = "http://www.w3.org/ns/sparql-service-description#namedGraph")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("entities", "triples")), objectProperties = list(unique = "defaultGraph", nonunique = c("datatypePartition", "classPartition", "propertyPartition", "namedGraph")))
   sparql <- makeSparql(propDict[flatProps],'Dataset', 'http://www.w3.org/ns/sparql-service-description#Dataset', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Dataset',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }