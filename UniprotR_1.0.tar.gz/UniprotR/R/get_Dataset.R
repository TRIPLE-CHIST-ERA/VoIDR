#' @title get_Dataset
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * entities -- -
#'  * triples -- -
#'  * classPartition -- -
#'  * propertyPartition -- -
#'  * defaultGraph -- -
#'  * datatypePartition -- -
#'  * namedGraph -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Dataset <- function(properties = list(literalProperties = list(nonunique = c("entities", "triples")), iriProperties = list(unique = c("classPartition", "propertyPartition", "defaultGraph"), nonunique = c("datatypePartition", "namedGraph"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(entities = "http://rdfs.org/ns/void#entities", triples = "http://rdfs.org/ns/void#triples", classPartition = "http://rdfs.org/ns/void#classPartition", propertyPartition = "http://rdfs.org/ns/void#propertyPartition", defaultGraph = "http://www.w3.org/ns/sparql-service-description#defaultGraph", datatypePartition = "http://ldf.fi/void-ext#datatypePartition", namedGraph = "http://www.w3.org/ns/sparql-service-description#namedGraph")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Dataset', 'http://www.w3.org/ns/sparql-service-description#Dataset', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }