#' @title get_Gene
#' @description Gene
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * locusName -- locus name
#'  * orfName -- ORF name
#'  * altLabel -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Gene <- function(properties = list(dataProperties = list(unique = "prefLabel", nonunique = c("locusName", "orfName", "altLabel"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", locusName = "http://purl.uniprot.org/core/locusName", orfName = "http://purl.uniprot.org/core/orfName", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = "prefLabel", nonunique = c("locusName", "orfName", "altLabel")))
   sparql <- makeSparql(propDict[flatProps],'Gene', 'http://purl.uniprot.org/core/Gene', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Gene',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }