#' @title get_Gene
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * locusName -- -
#'  * orfName -- -
#'  * altLabel -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Gene <- function(properties = list(literalProperties = list(nonunique = c("locusName", "orfName", "altLabel", "prefLabel"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(locusName = "http://purl.uniprot.org/core/locusName", orfName = "http://purl.uniprot.org/core/orfName", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Gene', 'http://purl.uniprot.org/core/Gene', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }