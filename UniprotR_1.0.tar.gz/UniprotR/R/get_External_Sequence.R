#' @title get_External_Sequence
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * fragment -- -
#'  * mass -- -
#'  * md5Checksum -- -
#'  * modified -- -
#'  * precursor -- -
#'  * version -- -
#'  * altLabel -- -
#'  * prefLabel -- -
#'  * basedOn -- -
#'  * citation -- -
#'  * modification -- -
#'  * translatedFrom -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_External_Sequence <- function(properties = list(literalProperties = list(nonunique = c("fragment", "mass", "md5Checksum", "modified", "precursor", "version", "rdf:value", "rdfs:comment", "altLabel", "prefLabel")), iriProperties = list(nonunique = c("basedOn", "citation", "modification", "translatedFrom"))), limit = 1000){
   iriProps <- list(literalProperties = list(nonunique = c("http://purl.uniprot.org/core/fragment", "http://purl.uniprot.org/core/mass", "http://purl.uniprot.org/core/md5Checksum", "http://purl.uniprot.org/core/modified", "http://purl.uniprot.org/core/precursor", "http://purl.uniprot.org/core/version", "rdf:value", "rdfs:comment", "http://www.w3.org/2004/02/skos/core#altLabel", "http://www.w3.org/2004/02/skos/core#prefLabel")), iriProperties = list(nonunique = c("http://purl.uniprot.org/core/basedOn", "http://purl.uniprot.org/core/citation", 
"http://purl.uniprot.org/core/modification", "http://purl.uniprot.org/core/translatedFrom")))
   sapply(names(properties), function(t){
    propType = properties[[t]]
    sapply(names(propType), function(card){
      propCard <- propType[[card]]
      propDict <- list()
      propDict[propCard] <- iriProps[[t]][[card]]
      propFilter <- paste(propDict[propCard], collapse='> <')
      sparql <- makeSparql(propFilter,'External_Sequence', 'http://purl.uniprot.org/core/External_Sequence', limit)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)
    }, simplify = FALSE)
   }, simplify = FALSE)

  }