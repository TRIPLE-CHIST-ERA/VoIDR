#' @title get_External_Sequence
#' @description The protein described in the linked record is an alternative splice form of the same gene product as described in this record. The function between the two isoforms is highly divergent.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * basedOn -- The sequence on which the description of a modified sequence is based.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * fragment -- Indicates if a sequence is complete or consists of one or more fragments.
#'  * mass -- The predicted mass of a sequence in Daltons.
#'  * modification -- A modification of a sequence.
#'  * modified -- The date a resource was last modified.
#'  * md5Checksum -- MD5 checksum
#'  * name -- name
#'  * precursor -- precursor
#'  * translatedFrom -- translated from
#'  * version -- version
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_External_Sequence <- function(properties = c("rdfs:comment", "fragment", "mass", "md5Checksum", "modified", "name", "precursor", "rdf:value", "version", "basedOn", "citation", "modification", "translatedFrom"), limit = 10000){
    propDict <- list()
    propDict[c("rdfs:comment", "fragment", "mass", "md5Checksum", "modified", "name", "precursor", "rdf:value", "version", "basedOn", "citation", "modification", "translatedFrom")] <- c("rdfs:comment", "http://purl.uniprot.org/core/fragment", "http://purl.uniprot.org/core/mass", "http://purl.uniprot.org/core/md5Checksum", "http://purl.uniprot.org/core/modified", "http://purl.uniprot.org/core/name", "http://purl.uniprot.org/core/precursor", "rdf:value", "http://purl.uniprot.org/core/version", "http://purl.uniprot.org/core/basedOn", "http://purl.uniprot.org/core/citation", "http://purl.uniprot.org/core/modification", "http://purl.uniprot.org/core/translatedFrom")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?External_Sequence a <',"http://purl.uniprot.org/core/External_Sequence",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?External_Sequence ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }