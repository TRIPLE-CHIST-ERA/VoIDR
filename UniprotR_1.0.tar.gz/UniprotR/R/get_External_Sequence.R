#' @title get_External_Sequence
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * fragment -- -
#'  * mass -- -
#'  * md5Checksum -- -
#'  * modified -- -
#'  * precursor -- -
#'  * version -- -
#'  * altLabel -- -
#'  * prefLabel -- -
#'  * basedOn -- -
#'  * citation -- -
#'  * modification -- -
#'  * translatedFrom -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_External_Sequence <- function(properties = list(literalProperties = list(nonunique = c("fragment", "mass", "md5Checksum", "modified", "precursor", "version", "rdf:value", "rdfs:comment", "altLabel", "prefLabel")), iriProperties = list(nonunique = c("basedOn", "citation", "modification", "translatedFrom"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(fragment = "http://purl.uniprot.org/core/fragment", mass = "http://purl.uniprot.org/core/mass", md5Checksum = "http://purl.uniprot.org/core/md5Checksum", modified = "http://purl.uniprot.org/core/modified", precursor = "http://purl.uniprot.org/core/precursor", version = "http://purl.uniprot.org/core/version", `rdf:value` = "rdf:value", `rdfs:comment` = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", basedOn = "http://purl.uniprot.org/core/basedOn", 
    citation = "http://purl.uniprot.org/core/citation", modification = "http://purl.uniprot.org/core/modification", translatedFrom = "http://purl.uniprot.org/core/translatedFrom")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'External_Sequence', 'http://purl.uniprot.org/core/External_Sequence', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }