#' @title get_External_Sequence
#' @description The protein described in the linked record is an alternative splice form of the same gene product as described in this record. The function between the two isoforms is highly divergent.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * basedOn -- The sequence on which the description of a modified sequence is based.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * fragment -- Indicates if a sequence is complete or consists of one or more fragments.
#'  * mass -- The predicted mass of a sequence in Daltons.
#'  * md5Checksum -- MD5 checksum
#'  * modification -- A modification of a sequence.
#'  * modified -- The date a resource was last modified.
#'  * precursor -- precursor
#'  * translatedFrom -- translated from
#'  * version -- version
#'  * altLabel -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_External_Sequence <- function(properties = list(dataProperties = list(unique = c("fragment", "md5Checksum", "modified", "precursor", "version", "rdf_value", "prefLabel"), nonunique = c("mass", "rdfs_comment", "altLabel")), objectProperties = list(unique = "basedOn", nonunique = c("citation", "modification", "translatedFrom"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(fragment = "http://purl.uniprot.org/core/fragment", md5Checksum = "http://purl.uniprot.org/core/md5Checksum", modified = "http://purl.uniprot.org/core/modified", precursor = "http://purl.uniprot.org/core/precursor", version = "http://purl.uniprot.org/core/version", rdf_value = "rdf:value", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", mass = "http://purl.uniprot.org/core/mass", rdfs_comment = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", basedOn = "http://purl.uniprot.org/core/basedOn", 
    citation = "http://purl.uniprot.org/core/citation", modification = "http://purl.uniprot.org/core/modification", translatedFrom = "http://purl.uniprot.org/core/translatedFrom")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("fragment", "md5Checksum", "modified", "precursor", "version", "rdf_value", "prefLabel"), nonunique = c("mass", "rdfs_comment", "altLabel")), objectProperties = list(unique = "basedOn", nonunique = c("citation", "modification", "translatedFrom")))
   sparql <- makeSparql(propDict[flatProps],'External_Sequence', 'http://purl.uniprot.org/core/External_Sequence', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('External_Sequence',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }