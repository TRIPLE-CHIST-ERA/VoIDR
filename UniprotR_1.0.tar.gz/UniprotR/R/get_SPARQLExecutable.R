#' @title get_SPARQLExecutable
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * ask -- -
#'  * construct -- -
#'  * describe -- -
#'  * prefixes -- -
#'  * select -- -
#'  * keyword -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_SPARQLExecutable <- function(properties = c("ask", "rdfs:comment", "construct", "describe", "keyword", "rdfs:label", "select", "prefixes"), limit = 1000){
    propDict <- list()
    propDict[c("ask", "rdfs:comment", "construct", "describe", "keyword", "rdfs:label", "select", "prefixes")] <- c("http://www.w3.org/ns/shacl#ask", "rdfs:comment", "http://www.w3.org/ns/shacl#construct", "http://www.w3.org/ns/shacl#describe", "https://schema.org/keyword", "rdfs:label", "http://www.w3.org/ns/shacl#select", "http://www.w3.org/ns/shacl#prefixes")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?SPARQLExecutable a <',"http://www.w3.org/ns/shacl#SPARQLExecutable",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?SPARQLExecutable ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }