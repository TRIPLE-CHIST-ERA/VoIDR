#' @title get_SPARQLExecutable
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * ask -- -
#'  * construct -- -
#'  * describe -- -
#'  * keyowrd -- -
#'  * keyowrds -- -
#'  * select -- -
#'  * keywords -- -
#'  * prefixes -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_SPARQLExecutable <- function(properties = list(literalProperties = list(unique = c("ask", "construct", "describe", "keyowrd", "keyowrds"), nonunique = c("rdfs_comment", "rdfs_label", "select", "keywords")), iriProperties = list(nonunique = "prefixes")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(ask = "http://www.w3.org/ns/shacl#ask", construct = "http://www.w3.org/ns/shacl#construct", describe = "https://purl.expasy.org/sparql-examples/ontology#describe", keyowrd = "https://schema.org/keyowrd", keyowrds = "https://schema.org/keyowrds", rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label", select = "http://www.w3.org/ns/shacl#select", keywords = "https://schema.org/keywords", prefixes = "http://www.w3.org/ns/shacl#prefixes")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(unique = c("ask", "construct", "describe", "keyowrd", "keyowrds"), nonunique = c("rdfs_comment", "rdfs_label", "select", "keywords")), iriProperties = list(nonunique = "prefixes"))
   sparql <- makeSparql(propDict[flatProps],'SPARQLExecutable', 'http://www.w3.org/ns/shacl#SPARQLExecutable', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('SPARQLExecutable',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }