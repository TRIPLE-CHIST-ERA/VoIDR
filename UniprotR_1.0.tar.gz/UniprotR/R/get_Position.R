#' @title get_Position
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * begin -- -
#'  * end -- -
#'  * position -- -
#'  * possiblePosition -- -
#'  * reference -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Position <- function(properties = list(dataProperties = list(unique = "position"), objectProperties = list(unique = c("begin", "end", "possiblePosition", "reference"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(position = "http://biohackathon.org/resource/faldo#position", begin = "http://biohackathon.org/resource/faldo#begin", end = "http://biohackathon.org/resource/faldo#end", possiblePosition = "http://biohackathon.org/resource/faldo#possiblePosition", reference = "http://biohackathon.org/resource/faldo#reference")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = "position"), objectProperties = list(unique = c("begin", "end", "possiblePosition", "reference")))
   sparql <- makeSparql(propDict[flatProps],'Position', 'http://biohackathon.org/resource/faldo#Position', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Position',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }