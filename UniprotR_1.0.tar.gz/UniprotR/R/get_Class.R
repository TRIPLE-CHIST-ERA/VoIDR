#' @title get_Class
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * accession -- -
#'  * hasExactSynonym -- -
#'  * charge -- -
#'  * curatedOrder -- -
#'  * equation -- -
#'  * formula -- -
#'  * htmlEquation -- -
#'  * htmlName -- -
#'  * id -- -
#'  * isChemicallyBalanced -- -
#'  * isTransport -- -
#'  * name -- -
#'  * polymerizationIndex -- -
#'  * position -- -
#'  * IAO_0000115 -- -
#'  * hasRelatedSynonym -- -
#'  * deprecated -- -
#'  * bidirectionalReaction -- -
#'  * contains10 -- -
#'  * contains11 -- -
#'  * contains12 -- -
#'  * contains13 -- -
#'  * contains14 -- -
#'  * contains16 -- -
#'  * contains17 -- -
#'  * contains18 -- -
#'  * contains19 -- -
#'  * contains2 -- -
#'  * contains20 -- -
#'  * contains21 -- -
#'  * contains22 -- -
#'  * contains24 -- -
#'  * contains26 -- -
#'  * contains27 -- -
#'  * contains28 -- -
#'  * contains2n -- -
#'  * contains3 -- -
#'  * contains32 -- -
#'  * contains4 -- -
#'  * contains40 -- -
#'  * contains5 -- -
#'  * contains6 -- -
#'  * contains7 -- -
#'  * contains8 -- -
#'  * contains9 -- -
#'  * containsN -- -
#'  * containsNminus1 -- -
#'  * containsNplus1 -- -
#'  * directionalReaction -- -
#'  * products -- -
#'  * reactivePart -- -
#'  * side -- -
#'  * substrates -- -
#'  * substratesOrProducts -- -
#'  * transformableTo -- -
#'  * replaces -- -
#'  * equivalentClass -- -
#'  * compound -- -
#'  * contains -- -
#'  * contains1 -- -
#'  * location -- -
#'  * status -- -
#'  * disjointWith -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Class <- function(properties = list(literalProperties = list(unique = c("accession", "hasExactSynonym"), nonunique = c("rdfs:comment", "rdfs:label", "charge", "curatedOrder", "equation", "formula", "htmlEquation", "htmlName", "id", "isChemicallyBalanced", "isTransport", "name", "polymerizationIndex", "position", "IAO_0000115", "hasRelatedSynonym", "deprecated")), iriProperties = list(unique = c("bidirectionalReaction", "contains10", "contains11", "contains12", "contains13", "contains14", "contains16", "contains17", "contains18", 
"contains19", "contains2", "contains20", "contains21", "contains22", "contains24", "contains26", "contains27", "contains28", "contains2n", "contains3", "contains32", "contains4", "contains40", "contains5", "contains6", "contains7", "contains8", "contains9", "containsN", "containsNminus1", "containsNplus1", "directionalReaction", "products", "reactivePart", "side", "substrates", "substratesOrProducts", "transformableTo", "replaces", "equivalentClass"), nonunique = c("rdfs:seeAlso", "rdfs:subClassOf", 
"compound", "contains", "contains1", "location", "status", "rdfs:isDefinedBy", "disjointWith"))), limit = 1000){
   iriProps <- list(literalProperties = list(unique = c("http://rdf.rhea-db.org/accession", "http://www.geneontology.org/formats/oboInOwl#hasExactSynonym"), nonunique = c("rdfs:comment", "rdfs:label", "http://rdf.rhea-db.org/charge", "http://rdf.rhea-db.org/curatedOrder", "http://rdf.rhea-db.org/equation", "http://rdf.rhea-db.org/formula", "http://rdf.rhea-db.org/htmlEquation", "http://rdf.rhea-db.org/htmlName", "http://rdf.rhea-db.org/id", "http://rdf.rhea-db.org/isChemicallyBalanced", "http://rdf.rhea-db.org/isTransport", 
"http://rdf.rhea-db.org/name", "http://rdf.rhea-db.org/polymerizationIndex", "http://rdf.rhea-db.org/position", "http://purl.obolibrary.org/obo/IAO_0000115", "http://www.geneontology.org/formats/oboInOwl#hasRelatedSynonym", "http://www.w3.org/2002/07/owl#deprecated")), iriProperties = list(unique = c("http://rdf.rhea-db.org/bidirectionalReaction", "http://rdf.rhea-db.org/contains10", "http://rdf.rhea-db.org/contains11", "http://rdf.rhea-db.org/contains12", "http://rdf.rhea-db.org/contains13", "http://rdf.rhea-db.org/contains14", 
"http://rdf.rhea-db.org/contains16", "http://rdf.rhea-db.org/contains17", "http://rdf.rhea-db.org/contains18", "http://rdf.rhea-db.org/contains19", "http://rdf.rhea-db.org/contains2", "http://rdf.rhea-db.org/contains20", "http://rdf.rhea-db.org/contains21", "http://rdf.rhea-db.org/contains22", "http://rdf.rhea-db.org/contains24", "http://rdf.rhea-db.org/contains26", "http://rdf.rhea-db.org/contains27", "http://rdf.rhea-db.org/contains28", "http://rdf.rhea-db.org/contains2n", "http://rdf.rhea-db.org/contains3", 
"http://rdf.rhea-db.org/contains32", "http://rdf.rhea-db.org/contains4", "http://rdf.rhea-db.org/contains40", "http://rdf.rhea-db.org/contains5", "http://rdf.rhea-db.org/contains6", "http://rdf.rhea-db.org/contains7", "http://rdf.rhea-db.org/contains8", "http://rdf.rhea-db.org/contains9", "http://rdf.rhea-db.org/containsN", "http://rdf.rhea-db.org/containsNminus1", "http://rdf.rhea-db.org/containsNplus1", "http://rdf.rhea-db.org/directionalReaction", "http://rdf.rhea-db.org/products", "http://rdf.rhea-db.org/reactivePart", 
"http://rdf.rhea-db.org/side", "http://rdf.rhea-db.org/substrates", "http://rdf.rhea-db.org/substratesOrProducts", "http://rdf.rhea-db.org/transformableTo", "http://www.geneontology.org/formats/oboInOwl#replaces", "http://www.w3.org/2002/07/owl#equivalentClass"), nonunique = c("rdfs:seeAlso", "rdfs:subClassOf", "http://rdf.rhea-db.org/compound", "http://rdf.rhea-db.org/contains", "http://rdf.rhea-db.org/contains1", "http://rdf.rhea-db.org/location", "http://rdf.rhea-db.org/status", "rdfs:isDefinedBy", 
"http://www.w3.org/2002/07/owl#disjointWith")))
   sapply(names(properties), function(t){
    propType = properties[[t]]
    sapply(names(propType), function(card){
      propCard <- propType[[card]]
      propDict <- list()
      propDict[propCard] <- iriProps[[t]][[card]]
      propFilter <- paste(propDict[propCard], collapse='> <')
      sparql <- makeSparql(propFilter,'Class', 'http://www.w3.org/2002/07/owl#Class', limit)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)
    }, simplify = FALSE)
   }, simplify = FALSE)

  }