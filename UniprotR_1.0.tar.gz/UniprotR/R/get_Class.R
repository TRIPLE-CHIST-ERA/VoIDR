#' @title get_Class
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * accession -- -
#'  * hasExactSynonym -- -
#'  * charge -- -
#'  * curatedOrder -- -
#'  * equation -- -
#'  * formula -- -
#'  * htmlEquation -- -
#'  * htmlName -- -
#'  * id -- -
#'  * isChemicallyBalanced -- -
#'  * isTransport -- -
#'  * name -- -
#'  * polymerizationIndex -- -
#'  * position -- -
#'  * IAO_0000115 -- -
#'  * hasRelatedSynonym -- -
#'  * deprecated -- -
#'  * bidirectionalReaction -- -
#'  * contains10 -- -
#'  * contains11 -- -
#'  * contains12 -- -
#'  * contains13 -- -
#'  * contains14 -- -
#'  * contains16 -- -
#'  * contains17 -- -
#'  * contains18 -- -
#'  * contains19 -- -
#'  * contains2 -- -
#'  * contains20 -- -
#'  * contains21 -- -
#'  * contains22 -- -
#'  * contains24 -- -
#'  * contains26 -- -
#'  * contains27 -- -
#'  * contains28 -- -
#'  * contains2n -- -
#'  * contains3 -- -
#'  * contains32 -- -
#'  * contains4 -- -
#'  * contains40 -- -
#'  * contains5 -- -
#'  * contains6 -- -
#'  * contains7 -- -
#'  * contains8 -- -
#'  * contains9 -- -
#'  * containsN -- -
#'  * containsNminus1 -- -
#'  * containsNplus1 -- -
#'  * directionalReaction -- -
#'  * products -- -
#'  * reactivePart -- -
#'  * side -- -
#'  * substrates -- -
#'  * substratesOrProducts -- -
#'  * transformableTo -- -
#'  * replaces -- -
#'  * equivalentClass -- -
#'  * compound -- -
#'  * contains -- -
#'  * contains1 -- -
#'  * location -- -
#'  * status -- -
#'  * disjointWith -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Class <- function(properties = list(literalProperties = list(unique = c("accession", "hasExactSynonym"), nonunique = c("rdfs_comment", "rdfs_label", "charge", "curatedOrder", "equation", "formula", "htmlEquation", "htmlName", "id", "isChemicallyBalanced", "isTransport", "name", "polymerizationIndex", "position", "IAO_0000115", "hasRelatedSynonym", "deprecated")), iriProperties = list(unique = c("bidirectionalReaction", "contains10", "contains11", "contains12", "contains13", "contains14", "contains16", "contains17", "contains18", 
"contains19", "contains2", "contains20", "contains21", "contains22", "contains24", "contains26", "contains27", "contains28", "contains2n", "contains3", "contains32", "contains4", "contains40", "contains5", "contains6", "contains7", "contains8", "contains9", "containsN", "containsNminus1", "containsNplus1", "directionalReaction", "products", "reactivePart", "side", "substrates", "substratesOrProducts", "transformableTo", "replaces", "equivalentClass"), nonunique = c("rdfs_seeAlso", "rdfs_subClassOf", 
"compound", "contains", "contains1", "location", "status", "rdfs_isDefinedBy", "disjointWith"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(accession = "http://rdf.rhea-db.org/accession", hasExactSynonym = "http://www.geneontology.org/formats/oboInOwl#hasExactSynonym", rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label", charge = "http://rdf.rhea-db.org/charge", curatedOrder = "http://rdf.rhea-db.org/curatedOrder", equation = "http://rdf.rhea-db.org/equation", formula = "http://rdf.rhea-db.org/formula", htmlEquation = "http://rdf.rhea-db.org/htmlEquation", htmlName = "http://rdf.rhea-db.org/htmlName", id = "http://rdf.rhea-db.org/id", 
    isChemicallyBalanced = "http://rdf.rhea-db.org/isChemicallyBalanced", isTransport = "http://rdf.rhea-db.org/isTransport", name = "http://rdf.rhea-db.org/name", polymerizationIndex = "http://rdf.rhea-db.org/polymerizationIndex", position = "http://rdf.rhea-db.org/position", IAO_0000115 = "http://purl.obolibrary.org/obo/IAO_0000115", hasRelatedSynonym = "http://www.geneontology.org/formats/oboInOwl#hasRelatedSynonym", deprecated = "http://www.w3.org/2002/07/owl#deprecated", bidirectionalReaction = "http://rdf.rhea-db.org/bidirectionalReaction", 
    contains10 = "http://rdf.rhea-db.org/contains10", contains11 = "http://rdf.rhea-db.org/contains11", contains12 = "http://rdf.rhea-db.org/contains12", contains13 = "http://rdf.rhea-db.org/contains13", contains14 = "http://rdf.rhea-db.org/contains14", contains16 = "http://rdf.rhea-db.org/contains16", contains17 = "http://rdf.rhea-db.org/contains17", contains18 = "http://rdf.rhea-db.org/contains18", contains19 = "http://rdf.rhea-db.org/contains19", contains2 = "http://rdf.rhea-db.org/contains2", 
    contains20 = "http://rdf.rhea-db.org/contains20", contains21 = "http://rdf.rhea-db.org/contains21", contains22 = "http://rdf.rhea-db.org/contains22", contains24 = "http://rdf.rhea-db.org/contains24", contains26 = "http://rdf.rhea-db.org/contains26", contains27 = "http://rdf.rhea-db.org/contains27", contains28 = "http://rdf.rhea-db.org/contains28", contains2n = "http://rdf.rhea-db.org/contains2n", contains3 = "http://rdf.rhea-db.org/contains3", contains32 = "http://rdf.rhea-db.org/contains32", 
    contains4 = "http://rdf.rhea-db.org/contains4", contains40 = "http://rdf.rhea-db.org/contains40", contains5 = "http://rdf.rhea-db.org/contains5", contains6 = "http://rdf.rhea-db.org/contains6", contains7 = "http://rdf.rhea-db.org/contains7", contains8 = "http://rdf.rhea-db.org/contains8", contains9 = "http://rdf.rhea-db.org/contains9", containsN = "http://rdf.rhea-db.org/containsN", containsNminus1 = "http://rdf.rhea-db.org/containsNminus1", containsNplus1 = "http://rdf.rhea-db.org/containsNplus1", 
    directionalReaction = "http://rdf.rhea-db.org/directionalReaction", products = "http://rdf.rhea-db.org/products", reactivePart = "http://rdf.rhea-db.org/reactivePart", side = "http://rdf.rhea-db.org/side", substrates = "http://rdf.rhea-db.org/substrates", substratesOrProducts = "http://rdf.rhea-db.org/substratesOrProducts", transformableTo = "http://rdf.rhea-db.org/transformableTo", replaces = "http://www.geneontology.org/formats/oboInOwl#replaces", equivalentClass = "http://www.w3.org/2002/07/owl#equivalentClass", 
    rdfs_seeAlso = "rdfs:seeAlso", rdfs_subClassOf = "rdfs:subClassOf", compound = "http://rdf.rhea-db.org/compound", contains = "http://rdf.rhea-db.org/contains", contains1 = "http://rdf.rhea-db.org/contains1", location = "http://rdf.rhea-db.org/location", status = "http://rdf.rhea-db.org/status", rdfs_isDefinedBy = "rdfs:isDefinedBy", disjointWith = "http://www.w3.org/2002/07/owl#disjointWith")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(unique = c("accession", "hasExactSynonym"), nonunique = c("rdfs_comment", "rdfs_label", "charge", "curatedOrder", "equation", "formula", "htmlEquation", "htmlName", "id", "isChemicallyBalanced", "isTransport", "name", "polymerizationIndex", "position", "IAO_0000115", "hasRelatedSynonym", "deprecated")), iriProperties = list(unique = c("bidirectionalReaction", "contains10", "contains11", "contains12", "contains13", "contains14", "contains16", "contains17", "contains18", 
"contains19", "contains2", "contains20", "contains21", "contains22", "contains24", "contains26", "contains27", "contains28", "contains2n", "contains3", "contains32", "contains4", "contains40", "contains5", "contains6", "contains7", "contains8", "contains9", "containsN", "containsNminus1", "containsNplus1", "directionalReaction", "products", "reactivePart", "side", "substrates", "substratesOrProducts", "transformableTo", "replaces", "equivalentClass"), nonunique = c("rdfs_seeAlso", "rdfs_subClassOf", 
"compound", "contains", "contains1", "location", "status", "rdfs_isDefinedBy", "disjointWith")))
   sparql <- makeSparql(propDict[flatProps],'Class', 'http://www.w3.org/2002/07/owl#Class', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Class',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }