#' @title get_Class
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * name -- name
#'  * hasDbXref -- -
#'  * hasId -- -
#'  * hasSynonym -- -
#'  * IAO_0000115 -- -
#'  * charge -- -
#'  * formula -- -
#'  * inchi -- -
#'  * inchikey -- -
#'  * smiles -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Class <- function(properties = c("IAO_0000115", "charge", "formula", "hasDbXref", "hasId", "hasSynonym", "inchi", "inchikey", "rdfs:label", "name", "smiles", "rdfs:subClassOf"), limit = 1000){
    propDict <- list()
    propDict[c("IAO_0000115", "charge", "formula", "hasDbXref", "hasId", "hasSynonym", "inchi", "inchikey", "rdfs:label", "name", "smiles", "rdfs:subClassOf")] <- c("http://purl.obolibrary.org/obo/IAO_0000115", "http://purl.obolibrary.org/obo/chebi/charge", "http://purl.obolibrary.org/obo/chebi/formula", "http://www.geneontology.org/formats/oboInOwl#hasDbXref", "http://www.geneontology.org/formats/oboInOwl#hasId", "http://www.geneontology.org/formats/oboInOwl#hasSynonym", "http://purl.obolibrary.org/obo/chebi/inchi", "http://purl.obolibrary.org/obo/chebi/inchikey", "rdfs:label", "http://purl.uniprot.org/core/name", "http://purl.obolibrary.org/obo/chebi/smiles", "rdfs:subClassOf")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Class a <',"http://www.w3.org/2002/07/owl#Class",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Class ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }