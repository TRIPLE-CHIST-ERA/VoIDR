#' @title get_Citation_Statement
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * scope -- -
#'  * context -- -
#'  * mappedAnnotation -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Citation_Statement <- function(properties = list(literalProperties = list(nonunique = "scope"), iriProperties = list(nonunique = c("context", "rdf_object", "rdf_subject", "mappedAnnotation"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(scope = "http://purl.uniprot.org/core/scope", context = "http://purl.uniprot.org/core/context", rdf_object = "rdf:object", rdf_subject = "rdf:subject", mappedAnnotation = "http://purl.uniprot.org/core/mappedAnnotation")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = "scope"), iriProperties = list(nonunique = c("context", "rdf_object", "rdf_subject", "mappedAnnotation")))
   sparql <- makeSparql(propDict[flatProps],'Citation_Statement', 'http://purl.uniprot.org/core/Citation_Statement', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Citation_Statement',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }