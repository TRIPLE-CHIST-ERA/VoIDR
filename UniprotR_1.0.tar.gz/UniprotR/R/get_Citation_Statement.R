#' @title get_Citation_Statement
#' @description The relationship between a resource and a citation.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * mappedAnnotation -- Maps annotation to a resource. Used to link annotations/comments from external non UniProt sources via Citations to UniProt resources.
#'  * scope -- The extent of the work carried out by the authors of a publication.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Citation_Statement <- function(properties = c("scope", "mappedAnnotation"), limit = 1000){
    propDict <- list()
    propDict[c("scope", "mappedAnnotation")] <- c("http://purl.uniprot.org/core/scope", "http://purl.uniprot.org/core/mappedAnnotation")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Citation_Statement a <',"http://purl.uniprot.org/core/Citation_Statement",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Citation_Statement ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }