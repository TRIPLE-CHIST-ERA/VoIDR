#' @title get_Citation_Statement
#' @description The relationship between a resource and a citation.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * context -- context
#'  * mappedAnnotation -- Maps annotation to a resource. Used to link annotations/comments from external non UniProt sources via Citations to UniProt resources.
#'  * scope -- The extent of the work carried out by the authors of a publication.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Citation_Statement <- function(properties = list(dataProperties = list(nonunique = "scope"), objectProperties = list(unique = "rdf_subject", nonunique = c("context", "rdf_object", "mappedAnnotation"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(scope = "http://purl.uniprot.org/core/scope", rdf_subject = "rdf:subject", context = "http://purl.uniprot.org/core/context", rdf_object = "rdf:object", mappedAnnotation = "http://purl.uniprot.org/core/mappedAnnotation")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(nonunique = "scope"), objectProperties = list(unique = "rdf_subject", nonunique = c("context", "rdf_object", "mappedAnnotation")))
   sparql <- makeSparql(propDict[flatProps],'Citation_Statement', 'http://purl.uniprot.org/core/Citation_Statement', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Citation_Statement',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }