#' @title get_rdf_Statement
#' @description get_rdf_Statement
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * scope -- -
#'  * citation -- -
#'  * context -- -
#'  * mappedAnnotation -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_rdf_Statement <- function(properties = list(literalProperties = list(nonunique = c("scope", "rdf_object")), iriProperties = list(nonunique = c("citation", "context", "rdf_object", "rdf_subject", "mappedAnnotation"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(scope = "http://purl.uniprot.org/core/scope", rdf_object = "rdf:object", citation = "http://purl.uniprot.org/core/citation", context = "http://purl.uniprot.org/core/context", rdf_subject = "rdf:subject", mappedAnnotation = "http://purl.uniprot.org/core/mappedAnnotation")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = c("scope", "rdf_object")), iriProperties = list(nonunique = c("citation", "context", "rdf_object", "rdf_subject", "mappedAnnotation")))
   sparql <- makeSparql(propDict[flatProps],'rdf_Statement', 'rdf:Statement', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('rdf_Statement',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }