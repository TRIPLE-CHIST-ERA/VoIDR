#' @title get_rdf_Statement
#' @description get_rdf_Statement
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * mappedAnnotation -- Maps annotation to a resource. Used to link annotations/comments from external non UniProt sources via Citations to UniProt resources.
#'  * scope -- The extent of the work carried out by the authors of a publication.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_rdf_Statement <- function(properties = c("rdf:object", "scope", "rdf:subject", "mappedAnnotation"), limit = 1000){
    propDict <- list()
    propDict[c("rdf:object", "scope", "rdf:subject", "mappedAnnotation")] <- c("rdf:object", "http://purl.uniprot.org/core/scope", "rdf:subject", "http://purl.uniprot.org/core/mappedAnnotation")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?rdf_Statement a <',"rdf:Statement",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?rdf_Statement ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }