#' @title get_Cellular_Component
#' @description Cellular Component
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * alias -- An alternative name used in the flat text format.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * partOf -- part of
#'  * relatedLocation -- related location
#'  * altLabel -- -
#'  * exactMatch -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Cellular_Component <- function(properties = list(dataProperties = list(unique = c("prefLabel", "alias"), nonunique = c("rdfs_comment", "altLabel")), objectProperties = list(unique = "exactMatch", nonunique = c("citation", "partOf", "rdfs_subClassOf", "relatedLocation"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", alias = "http://purl.uniprot.org/core/alias", rdfs_comment = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", exactMatch = "http://www.w3.org/2004/02/skos/core#exactMatch", citation = "http://purl.uniprot.org/core/citation", partOf = "http://purl.uniprot.org/core/partOf", rdfs_subClassOf = "rdfs:subClassOf", relatedLocation = "http://purl.uniprot.org/core/relatedLocation")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("prefLabel", "alias"), nonunique = c("rdfs_comment", "altLabel")), objectProperties = list(unique = "exactMatch", nonunique = c("citation", "partOf", "rdfs_subClassOf", "relatedLocation")))
   sparql <- makeSparql(propDict[flatProps],'Cellular_Component', 'http://purl.uniprot.org/core/Cellular_Component', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Cellular_Component',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }