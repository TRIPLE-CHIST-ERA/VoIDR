#' @title get_Cellular_Component
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * alias -- -
#'  * altLabel -- -
#'  * prefLabel -- -
#'  * citation -- -
#'  * partOf -- -
#'  * exactMatch -- -
#'  * relatedLocation -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Cellular_Component <- function(properties = list(literalProperties = list(unique = "alias", nonunique = c("rdfs_comment", "altLabel", "prefLabel")), iriProperties = list(nonunique = c("citation", "partOf", "rdfs_subClassOf", "exactMatch", "relatedLocation"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(alias = "http://purl.uniprot.org/core/alias", rdfs_comment = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", citation = "http://purl.uniprot.org/core/citation", partOf = "http://purl.uniprot.org/core/partOf", rdfs_subClassOf = "rdfs:subClassOf", exactMatch = "http://www.w3.org/2004/02/skos/core#exactMatch", relatedLocation = "http://purl.uniprot.org/core/relatedLocation")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(unique = "alias", nonunique = c("rdfs_comment", "altLabel", "prefLabel")), iriProperties = list(nonunique = c("citation", "partOf", "rdfs_subClassOf", "exactMatch", "relatedLocation")))
   sparql <- makeSparql(propDict[flatProps],'Cellular_Component', 'http://purl.uniprot.org/core/Cellular_Component', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Cellular_Component',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }