#' @title get_Journal
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * shortCoden -- Used to link a Journal to its shortCoden
#'  * publisher -- -
#'  * coden -- -
#'  * eissn -- -
#'  * issn -- -
#'  * shortTitle -- -
#'  * title -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Journal <- function(properties = c("coden", "rdfs:comment", "eissn", "issn", "publisher", "shortCoden", "shortTitle", "title"), limit = 1000){
    propDict <- list()
    propDict[c("coden", "rdfs:comment", "eissn", "issn", "publisher", "shortCoden", "shortTitle", "title")] <- c("http://purl.org/ontology/bibo/coden", "rdfs:comment", "http://purl.org/ontology/bibo/eissn", "http://purl.org/ontology/bibo/issn", "http://purl.org/dc/terms/publisher", "http://purl.uniprot.org/core/shortCoden", "http://purl.org/ontology/bibo/shortTitle", "http://purl.org/ontology/bibo/title")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Journal a <',"http://purl.org/ontology/bibo/Journal",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Journal ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }