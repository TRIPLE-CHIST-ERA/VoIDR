#' @title get_Journal
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * coden -- -
#'  * eissn -- -
#'  * issn -- -
#'  * shortTitle -- -
#'  * title -- -
#'  * publisher -- -
#'  * shortCoden -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Journal <- function(properties = list(literalProperties = list(unique = c("coden", "eissn", "issn", "shortTitle", "title"), nonunique = c("rdfs_comment", "publisher", "shortCoden"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(coden = "http://purl.org/ontology/bibo/coden", eissn = "http://purl.org/ontology/bibo/eissn", issn = "http://purl.org/ontology/bibo/issn", shortTitle = "http://purl.org/ontology/bibo/shortTitle", title = "http://purl.org/ontology/bibo/title", rdfs_comment = "rdfs:comment", publisher = "http://purl.org/dc/terms/publisher", shortCoden = "http://purl.uniprot.org/core/shortCoden")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(unique = c("coden", "eissn", "issn", "shortTitle", "title"), nonunique = c("rdfs_comment", "publisher", "shortCoden")))
   sparql <- makeSparql(propDict[flatProps],'Journal', 'http://purl.org/ontology/bibo/Journal', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Journal',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }