#' @title get_Service
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * defaultDataset -- -
#'  * endpoint -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Service <- function(properties = list(iriProperties = list(unique = c("defaultDataset", "endpoint"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(defaultDataset = "http://www.w3.org/ns/sparql-service-description#defaultDataset", endpoint = "http://www.w3.org/ns/sparql-service-description#endpoint")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(iriProperties = list(unique = c("defaultDataset", "endpoint")))
   sparql <- makeSparql(propDict[flatProps],'Service', 'http://www.w3.org/ns/sparql-service-description#Service', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Service',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }