#' @title get_InverseFunctionalProperty
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_InverseFunctionalProperty <- function(properties = list(literalProperties = list(nonunique = "rdfs_label"), iriProperties = list(nonunique = c("rdfs_domain", "rdfs_isDefinedBy", "rdfs_range"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_label = "rdfs:label", rdfs_domain = "rdfs:domain", rdfs_isDefinedBy = "rdfs:isDefinedBy", rdfs_range = "rdfs:range")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = "rdfs_label"), iriProperties = list(nonunique = c("rdfs_domain", "rdfs_isDefinedBy", "rdfs_range")))
   sparql <- makeSparql(propDict[flatProps],'InverseFunctionalProperty', 'http://www.w3.org/2002/07/owl#InverseFunctionalProperty', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('InverseFunctionalProperty',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }