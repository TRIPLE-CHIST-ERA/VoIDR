#' @title get_InverseFunctionalProperty
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_InverseFunctionalProperty <- function(properties = list(literalProperties = list(nonunique = "rdfs:label"), iriProperties = list(nonunique = c("rdfs:domain", "rdfs:isDefinedBy", "rdfs:range"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(`rdfs:label` = "rdfs:label", `rdfs:domain` = "rdfs:domain", `rdfs:isDefinedBy` = "rdfs:isDefinedBy", `rdfs:range` = "rdfs:range")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'InverseFunctionalProperty', 'http://www.w3.org/2002/07/owl#InverseFunctionalProperty', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }