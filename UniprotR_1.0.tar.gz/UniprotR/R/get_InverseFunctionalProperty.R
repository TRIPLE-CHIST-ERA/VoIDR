#' @title get_InverseFunctionalProperty
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_InverseFunctionalProperty <- function(properties = list(dataProperties = list(nonunique = "rdfs_label"), objectProperties = list(unique = c("rdfs_domain", "rdfs_isDefinedBy", "rdfs_range"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_label = "rdfs:label", rdfs_domain = "rdfs:domain", rdfs_isDefinedBy = "rdfs:isDefinedBy", rdfs_range = "rdfs:range")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(nonunique = "rdfs_label"), objectProperties = list(unique = c("rdfs_domain", "rdfs_isDefinedBy", "rdfs_range")))
   sparql <- makeSparql(propDict[flatProps],'InverseFunctionalProperty', 'http://www.w3.org/2002/07/owl#InverseFunctionalProperty', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('InverseFunctionalProperty',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }