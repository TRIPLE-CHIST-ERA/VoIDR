makeSparql <- function( propFilter, shortName, longName, limit = NULL, only.complete.cases = FALSE){
  if(only.complete.cases){
    linePrefix = ''
  } else {
    linePrefix = 'OPTIONAL'
  }
  selectLimitClause <- paste0("{SELECT ?", shortName, "\n WHERE { ?", shortName, " a <", longName, ">}\n")
  if(!is.null(limit)){
    selectLimitClause <- paste0(selectLimitClause, ' LIMIT ', format(limit, scientific = FALSE), "\n")
  }
  selectLimitClause <- paste0(selectLimitClause, "\n }")
  joinClause <- Reduce(function(x,y) {
    ret <- paste0(x, linePrefix, '{ ?', shortName, ' <',  propFilter[[y]], '> ')
    if(!grepl(':', ret)){
      ret <- paste0(ret, '?')
    }
    paste0(ret, y , "}\n" )
  }, names(propFilter), init = '')


  sparql <- paste0("SELECT *\n WHERE {\n", selectLimitClause, joinClause, "\n}")

  return(sparql)
}
