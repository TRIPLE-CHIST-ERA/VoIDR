#' @title get_Sequence
#' @description An amino acid sequence.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * length -- length
#'  * memberOf -- member of
#'  * representativeFor -- representative for
#'  * seedFor -- seed for
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Sequence <- function(properties = list(dataProperties = list(nonunique = c("rdfs_label", "length")), objectProperties = list(nonunique = c("memberOf", "representativeFor", "seedFor"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_label = "rdfs:label", length = "http://purl.uniprot.org/core/length", memberOf = "http://purl.uniprot.org/core/memberOf", representativeFor = "http://purl.uniprot.org/core/representativeFor", seedFor = "http://purl.uniprot.org/core/seedFor")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(nonunique = c("rdfs_label", "length")), objectProperties = list(nonunique = c("memberOf", "representativeFor", "seedFor")))
   sparql <- makeSparql(propDict[flatProps],'Sequence', 'http://purl.uniprot.org/core/Sequence', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Sequence',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }