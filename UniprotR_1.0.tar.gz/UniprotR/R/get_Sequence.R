#' @title get_Sequence
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * length -- -
#'  * representativeFor -- -
#'  * seedFor -- -
#'  * memberOf -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Sequence <- function(properties = list(literalProperties = list(nonunique = c("rdfs:label", "length")), iriProperties = list(unique = c("representativeFor", "seedFor"), nonunique = "memberOf")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(`rdfs:label` = "rdfs:label", length = "http://purl.uniprot.org/core/length", representativeFor = "http://purl.uniprot.org/core/representativeFor", seedFor = "http://purl.uniprot.org/core/seedFor", memberOf = "http://purl.uniprot.org/core/memberOf")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Sequence', 'http://purl.uniprot.org/core/Sequence', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }