#' @title get_Natural_Variant_Annotation
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * substitution -- -
#'  * range -- -
#'  * sequence -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Natural_Variant_Annotation <- function(properties = list(literalProperties = list(nonunique = c("substitution", "rdfs_comment")), iriProperties = list(nonunique = c("range", "sequence"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(substitution = "http://purl.uniprot.org/core/substitution", rdfs_comment = "rdfs:comment", range = "http://purl.uniprot.org/core/range", sequence = "http://purl.uniprot.org/core/sequence")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = c("substitution", "rdfs_comment")), iriProperties = list(nonunique = c("range", "sequence")))
   sparql <- makeSparql(propDict[flatProps],'Natural_Variant_Annotation', 'http://purl.uniprot.org/core/Natural_Variant_Annotation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Natural_Variant_Annotation',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }