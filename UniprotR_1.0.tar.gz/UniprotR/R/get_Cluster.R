#' @title get_Cluster
#' @description Cluster of proteins with similar sequences.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * identity -- The level of sequence identity in a cluster.
#'  * member -- One of several similar resources.
#'  * modified -- The date a resource was last modified.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Cluster <- function(properties = list(dataProperties = list(unique = c("modified", "identity"), nonunique = "rdfs_label"), objectProperties = list(nonunique = "member")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(modified = "http://purl.uniprot.org/core/modified", identity = "http://purl.uniprot.org/core/identity", rdfs_label = "rdfs:label", member = "http://purl.uniprot.org/core/member")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("modified", "identity"), nonunique = "rdfs_label"), objectProperties = list(nonunique = "member"))
   sparql <- makeSparql(propDict[flatProps],'Cluster', 'http://purl.uniprot.org/core/Cluster', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Cluster',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }