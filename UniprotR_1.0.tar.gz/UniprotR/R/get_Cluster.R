#' @title get_Cluster
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * modified -- -
#'  * identity -- -
#'  * member -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Cluster <- function(properties = list(literalProperties = list(nonunique = c("modified", "rdfs:label", "identity")), iriProperties = list(nonunique = "member")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(modified = "http://purl.uniprot.org/core/modified", `rdfs:label` = "rdfs:label", identity = "http://purl.uniprot.org/core/identity", member = "http://purl.uniprot.org/core/member")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Cluster', 'http://purl.uniprot.org/core/Cluster', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }