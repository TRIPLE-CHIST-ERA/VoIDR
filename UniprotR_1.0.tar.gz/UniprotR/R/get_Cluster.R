#' @title get_Cluster
#' @description Cluster of proteins with similar sequences.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * identity -- The level of sequence identity in a cluster.
#'  * member -- One of several similar resources.
#'  * modified -- The date a resource was last modified.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Cluster <- function(properties = c("identity", "rdfs:label", "modified", "member"), limit = 1000){
    propDict <- list()
    propDict[c("identity", "rdfs:label", "modified", "member")] <- c("http://purl.uniprot.org/core/identity", "rdfs:label", "http://purl.uniprot.org/core/modified", "http://purl.uniprot.org/core/member")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Cluster a <',"http://purl.uniprot.org/core/Cluster",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Cluster ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }