#' @title get_RNA_Editing_Annotation
#' @description Description of any type of RNA editing that leads to one or more amino acid changes.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * location -- -
#'  * frameshift -- True if a sequence modification causes a frameshift.
#'  * sequence -- An amino acid sequence.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_RNA_Editing_Annotation <- function(properties = list(dataProperties = list(unique = "frameshift", nonunique = "rdfs_comment"), objectProperties = list(nonunique = c("location", "sequence"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(frameshift = "http://purl.uniprot.org/core/frameshift", rdfs_comment = "rdfs:comment", location = "http://biohackathon.org/resource/faldo#location", sequence = "http://purl.uniprot.org/core/sequence")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = "frameshift", nonunique = "rdfs_comment"), objectProperties = list(nonunique = c("location", "sequence")))
   sparql <- makeSparql(propDict[flatProps],'RNA_Editing_Annotation', 'http://purl.uniprot.org/core/RNA_Editing_Annotation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('RNA_Editing_Annotation',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }