#' @title get_Pathway_Annotation
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * sequence -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Pathway_Annotation <- function(properties = list(iriProperties = list(nonunique = "sequence")), limit = 1000){
   iriProps <- list(iriProperties = list(nonunique = "http://purl.uniprot.org/core/sequence"))
   sapply(names(properties), function(t){
    propType = properties[[t]]
    sapply(names(propType), function(card){
      propCard <- propType[[card]]
      propDict <- list()
      propDict[propCard] <- iriProps[[t]][[card]]
      propFilter <- paste(propDict[propCard], collapse='> <')
      sparql <- makeSparql(propFilter,'Pathway_Annotation', 'http://purl.uniprot.org/core/Pathway_Annotation', limit)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)
    }, simplify = FALSE)
   }, simplify = FALSE)

  }