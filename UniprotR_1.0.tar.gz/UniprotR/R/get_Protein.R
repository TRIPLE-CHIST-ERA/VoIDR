#' @title get_Protein
#' @description Description of a protein.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * alternativeName -- A synonym of the recommended name.
#'  * annotation -- Attaches an annotation to a resource.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * complete -- complete
#'  * component -- A component of a protein.
#'  * conflictingSequence -- conflicting sequence
#'  * created -- The date a resource was created.
#'  * domain -- A domain of a protein.
#'  * encodedBy -- The gene by which a protein is encoded.
#'  * encodedIn -- The subcellular location where a protein is encoded.
#'  * interaction -- interaction
#'  * isolatedFrom -- isolatedFrom
#'  * mnemonic -- A easy to remember identifier for a UniProtKB entry, but it is not a stable identifier and should not be used by programs to identify entries.
#'  * modified -- The date a resource was last modified.
#'  * obsolete -- True if this resource has been replaced or deleted.
#'  * oldMnemonic -- A mnemonic that is no longer in use for this entry.
#'  * potentialSequence -- This is a predicate added by an automated procedure to link entries/proteins that might be isoforms of each other.
#'  * recommendedName -- The name recommended by the UniProt consortium.
#'  * replacedBy -- A resource that replaces this resource.
#'  * reviewed -- Indicates whether a resource has been reviewed by a curator.
#'  * sequence -- An amino acid sequence.
#'  * submittedName -- A name provided by the submitter of the underlying nucleotide sequence.
#'  * version -- version
#'  * withdrawnFromINSDC -- withdrawnFromINSDC
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Protein <- function(properties = list(dataProperties = list(unique = c("complete", "created", "mnemonic", "modified", "reviewed", "version", "obsolete", "withdrawnFromINSDC"), nonunique = "oldMnemonic"), objectProperties = list(unique = "recommendedName", nonunique = c("alternativeName", "annotation", "citation", "component", "conflictingSequence", "domain", "encodedBy", "encodedIn", "interaction", "isolatedFrom", "potentialSequence", "sequence", "submittedName", "rdfs_seeAlso", "replacedBy"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(complete = "http://purl.uniprot.org/core/complete", created = "http://purl.uniprot.org/core/created", mnemonic = "http://purl.uniprot.org/core/mnemonic", modified = "http://purl.uniprot.org/core/modified", reviewed = "http://purl.uniprot.org/core/reviewed", version = "http://purl.uniprot.org/core/version", obsolete = "http://purl.uniprot.org/core/obsolete", withdrawnFromINSDC = "http://purl.uniprot.org/core/withdrawnFromINSDC", oldMnemonic = "http://purl.uniprot.org/core/oldMnemonic", recommendedName = "http://purl.uniprot.org/core/recommendedName", 
    alternativeName = "http://purl.uniprot.org/core/alternativeName", annotation = "http://purl.uniprot.org/core/annotation", citation = "http://purl.uniprot.org/core/citation", component = "http://purl.uniprot.org/core/component", conflictingSequence = "http://purl.uniprot.org/core/conflictingSequence", domain = "http://purl.uniprot.org/core/domain", encodedBy = "http://purl.uniprot.org/core/encodedBy", encodedIn = "http://purl.uniprot.org/core/encodedIn", interaction = "http://purl.uniprot.org/core/interaction", 
    isolatedFrom = "http://purl.uniprot.org/core/isolatedFrom", potentialSequence = "http://purl.uniprot.org/core/potentialSequence", sequence = "http://purl.uniprot.org/core/sequence", submittedName = "http://purl.uniprot.org/core/submittedName", rdfs_seeAlso = "rdfs:seeAlso", replacedBy = "http://purl.uniprot.org/core/replacedBy")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("complete", "created", "mnemonic", "modified", "reviewed", "version", "obsolete", "withdrawnFromINSDC"), nonunique = "oldMnemonic"), objectProperties = list(unique = "recommendedName", nonunique = c("alternativeName", "annotation", "citation", "component", "conflictingSequence", "domain", "encodedBy", "encodedIn", "interaction", "isolatedFrom", "potentialSequence", "sequence", "submittedName", "rdfs_seeAlso", "replacedBy")))
   sparql <- makeSparql(propDict[flatProps],'Protein', 'http://purl.uniprot.org/core/Protein', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Protein',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }