#' @title get_Protein
#' @description Description of a protein.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * created -- The date a resource was created.
#'  * mnemonic -- A rememberable string that can be used to find entries, not a stable identifier!
#'  * mnemonic -- A easy to remember identifier for a UniProtKB entry, but it is not a stable identifier and should not be used by programs to identify entries.
#'  * modified -- The date a resource was last modified.
#'  * obsolete -- True if this resource has been replaced or deleted.
#'  * oldMnemonic -- A mnemonic that is no longer in use for this entry.
#'  * replacedBy -- A resource that replaces this resource.
#'  * reviewed -- Indicates whether a resource has been reviewed by a curator.
#'  * version -- version
#'  * withdrawnFromINSDC -- withdrawnFromINSDC
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_Protein <- function(properties = c("created", "mnemonic", "modified", "obsolete", "oldMnemonic", "reviewed", "version", "withdrawnFromINSDC", "replacedBy"), limit = 10000){
    propDict <- list()
    propDict[c("created", "mnemonic", "modified", "obsolete", "oldMnemonic", "reviewed", "version", "withdrawnFromINSDC", "replacedBy")] <- c("http://purl.uniprot.org/core/created", "http://purl.uniprot.org/core/mnemonic", "http://purl.uniprot.org/core/modified", "http://purl.uniprot.org/core/obsolete", "http://purl.uniprot.org/core/oldMnemonic", "http://purl.uniprot.org/core/reviewed", "http://purl.uniprot.org/core/version", "http://purl.uniprot.org/core/withdrawnFromINSDC", "http://purl.uniprot.org/core/replacedBy")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Protein a <',"http://purl.uniprot.org/core/Protein",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Protein ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }