#' @title get_Protein
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * complete -- -
#'  * created -- -
#'  * mnemonic -- -
#'  * modified -- -
#'  * oldMnemonic -- -
#'  * reviewed -- -
#'  * version -- -
#'  * obsolete -- -
#'  * withdrawnFromINSDC -- -
#'  * component -- -
#'  * domain -- -
#'  * encodedBy -- -
#'  * submittedName -- -
#'  * alternativeName -- -
#'  * annotation -- -
#'  * citation -- -
#'  * conflictingSequence -- -
#'  * encodedIn -- -
#'  * interaction -- -
#'  * isolatedFrom -- -
#'  * potentialSequence -- -
#'  * recommendedName -- -
#'  * sequence -- -
#'  * replacedBy -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Protein <- function(properties = list(literalProperties = list(nonunique = c("complete", "created", "mnemonic", "modified", "oldMnemonic", "reviewed", "version", "obsolete", "withdrawnFromINSDC")), iriProperties = list(unique = c("component", "domain", "encodedBy", "submittedName"), nonunique = c("alternativeName", "annotation", "citation", "conflictingSequence", "encodedIn", "interaction", "isolatedFrom", "potentialSequence", "recommendedName", "sequence", "rdfs:seeAlso", "replacedBy"))), limit = 1000){
   iriProps <- list(literalProperties = list(nonunique = c("http://purl.uniprot.org/core/complete", "http://purl.uniprot.org/core/created", "http://purl.uniprot.org/core/mnemonic", "http://purl.uniprot.org/core/modified", "http://purl.uniprot.org/core/oldMnemonic", "http://purl.uniprot.org/core/reviewed", "http://purl.uniprot.org/core/version", "http://purl.uniprot.org/core/obsolete", "http://purl.uniprot.org/core/withdrawnFromINSDC")), iriProperties = list(unique = c("http://purl.uniprot.org/core/component", "http://purl.uniprot.org/core/domain", 
"http://purl.uniprot.org/core/encodedBy", "http://purl.uniprot.org/core/submittedName"), nonunique = c("http://purl.uniprot.org/core/alternativeName", "http://purl.uniprot.org/core/annotation", "http://purl.uniprot.org/core/citation", "http://purl.uniprot.org/core/conflictingSequence", "http://purl.uniprot.org/core/encodedIn", "http://purl.uniprot.org/core/interaction", "http://purl.uniprot.org/core/isolatedFrom", "http://purl.uniprot.org/core/potentialSequence", "http://purl.uniprot.org/core/recommendedName", 
"http://purl.uniprot.org/core/sequence", "rdfs:seeAlso", "http://purl.uniprot.org/core/replacedBy")))
   sapply(names(properties), function(t){
    propType = properties[[t]]
    sapply(names(propType), function(card){
      propCard <- propType[[card]]
      propDict <- list()
      propDict[propCard] <- iriProps[[t]][[card]]
      propFilter <- paste(propDict[propCard], collapse='> <')
      sparql <- makeSparql(propFilter,'Protein', 'http://purl.uniprot.org/core/Protein', limit)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)
    }, simplify = FALSE)
   }, simplify = FALSE)

  }