#' @title get_Protein
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * complete -- -
#'  * created -- -
#'  * mnemonic -- -
#'  * modified -- -
#'  * oldMnemonic -- -
#'  * reviewed -- -
#'  * version -- -
#'  * obsolete -- -
#'  * withdrawnFromINSDC -- -
#'  * component -- -
#'  * domain -- -
#'  * encodedBy -- -
#'  * submittedName -- -
#'  * alternativeName -- -
#'  * annotation -- -
#'  * citation -- -
#'  * conflictingSequence -- -
#'  * encodedIn -- -
#'  * interaction -- -
#'  * isolatedFrom -- -
#'  * potentialSequence -- -
#'  * recommendedName -- -
#'  * sequence -- -
#'  * replacedBy -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Protein <- function(properties = list(literalProperties = list(nonunique = c("complete", "created", "mnemonic", "modified", "oldMnemonic", "reviewed", "version", "obsolete", "withdrawnFromINSDC")), iriProperties = list(unique = c("component", "domain", "encodedBy", "submittedName"), nonunique = c("alternativeName", "annotation", "citation", "conflictingSequence", "encodedIn", "interaction", "isolatedFrom", "potentialSequence", "recommendedName", "sequence", "rdfs:seeAlso", "replacedBy"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(complete = "http://purl.uniprot.org/core/complete", created = "http://purl.uniprot.org/core/created", mnemonic = "http://purl.uniprot.org/core/mnemonic", modified = "http://purl.uniprot.org/core/modified", oldMnemonic = "http://purl.uniprot.org/core/oldMnemonic", reviewed = "http://purl.uniprot.org/core/reviewed", version = "http://purl.uniprot.org/core/version", obsolete = "http://purl.uniprot.org/core/obsolete", withdrawnFromINSDC = "http://purl.uniprot.org/core/withdrawnFromINSDC", component = "http://purl.uniprot.org/core/component", 
    domain = "http://purl.uniprot.org/core/domain", encodedBy = "http://purl.uniprot.org/core/encodedBy", submittedName = "http://purl.uniprot.org/core/submittedName", alternativeName = "http://purl.uniprot.org/core/alternativeName", annotation = "http://purl.uniprot.org/core/annotation", citation = "http://purl.uniprot.org/core/citation", conflictingSequence = "http://purl.uniprot.org/core/conflictingSequence", encodedIn = "http://purl.uniprot.org/core/encodedIn", interaction = "http://purl.uniprot.org/core/interaction", 
    isolatedFrom = "http://purl.uniprot.org/core/isolatedFrom", potentialSequence = "http://purl.uniprot.org/core/potentialSequence", recommendedName = "http://purl.uniprot.org/core/recommendedName", sequence = "http://purl.uniprot.org/core/sequence", `rdfs:seeAlso` = "rdfs:seeAlso", replacedBy = "http://purl.uniprot.org/core/replacedBy")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Protein', 'http://purl.uniprot.org/core/Protein', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }