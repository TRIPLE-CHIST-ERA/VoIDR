#' @title get_Submission_Citation
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * author -- -
#'  * date -- -
#'  * group -- -
#'  * submittedTo -- -
#'  * title -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Submission_Citation <- function(properties = list(literalProperties = list(nonunique = c("author", "date", "group", "submittedTo", "title"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(author = "http://purl.uniprot.org/core/author", date = "http://purl.uniprot.org/core/date", group = "http://purl.uniprot.org/core/group", submittedTo = "http://purl.uniprot.org/core/submittedTo", title = "http://purl.uniprot.org/core/title")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = c("author", "date", "group", "submittedTo", "title")))
   sparql <- makeSparql(propDict[flatProps],'Submission_Citation', 'http://purl.uniprot.org/core/Submission_Citation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Submission_Citation',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }