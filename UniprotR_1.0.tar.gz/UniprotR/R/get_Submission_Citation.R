#' @title get_Submission_Citation
#' @description Data that was submitted directly to a database.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * author -- The author of a publication.
#'  * date -- date
#'  * group -- The group or consortium that authored a publication.
#'  * submittedTo -- The database a resource  was submitted to.
#'  * title -- The title of a publication.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Submission_Citation <- function(properties = list(dataProperties = list(unique = c("date", "submittedTo", "title"), nonunique = c("author", "group"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(date = "http://purl.uniprot.org/core/date", submittedTo = "http://purl.uniprot.org/core/submittedTo", title = "http://purl.uniprot.org/core/title", author = "http://purl.uniprot.org/core/author", group = "http://purl.uniprot.org/core/group")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("date", "submittedTo", "title"), nonunique = c("author", "group")))
   sparql <- makeSparql(propDict[flatProps],'Submission_Citation', 'http://purl.uniprot.org/core/Submission_Citation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Submission_Citation',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }