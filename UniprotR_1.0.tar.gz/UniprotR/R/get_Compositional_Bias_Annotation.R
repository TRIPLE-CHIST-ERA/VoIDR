#' @title get_Compositional_Bias_Annotation
#' @description Extent of a compositionally biased region.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * range -- A specialization of faldo:location where all objects are faldo:Regions
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_Compositional_Bias_Annotation <- function(properties = c("rdfs:comment", "range"), limit = 10000){
    propDict <- list()
    propDict[c("rdfs:comment", "range")] <- c("rdfs:comment", "http://purl.uniprot.org/core/range")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Compositional_Bias_Annotation a <',"http://purl.uniprot.org/core/Compositional_Bias_Annotation",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Compositional_Bias_Annotation ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }