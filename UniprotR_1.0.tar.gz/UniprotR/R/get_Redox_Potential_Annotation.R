#' @title get_Redox_Potential_Annotation
#' @description Reports the value of the standard (midpoint) oxido-reduction potential(s) for electron transport proteins.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Redox_Potential_Annotation <- function(properties = c("rdfs:comment"), limit = 1000){
    propDict <- list()
    propDict[c("rdfs:comment")] <- c("rdfs:comment")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Redox_Potential_Annotation a <',"http://purl.uniprot.org/core/Redox_Potential_Annotation",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Redox_Potential_Annotation ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }