#' @title get_Catalytic_Activity
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Catalytic_Activity <- function(properties = list(literalProperties = list(nonunique = "rdfs:label")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(`rdfs:label` = "rdfs:label")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Catalytic_Activity', 'http://purl.uniprot.org/core/Catalytic_Activity', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }