#' @title get_Plasmid
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Plasmid <- function(properties = list(literalProperties = list(nonunique = "rdfs_label")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_label = "rdfs:label")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = "rdfs_label"))
   sparql <- makeSparql(propDict[flatProps],'Plasmid', 'http://purl.uniprot.org/core/Plasmid', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Plasmid',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }