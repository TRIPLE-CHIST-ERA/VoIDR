#' @title get_Nucleotide_Resource
#' @description A resource that descripes a nucleotide sequence.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * citation -- A publication from which data was extracted, or which contains additional information.
#'  * locatedOn -- The molecule a this resource is located on.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Nucleotide_Resource <- function(properties = list(objectProperties = list(nonunique = c("citation", "locatedOn"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(citation = "http://purl.uniprot.org/core/citation", locatedOn = "http://purl.uniprot.org/core/locatedOn")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(objectProperties = list(nonunique = c("citation", "locatedOn")))
   sparql <- makeSparql(propDict[flatProps],'Nucleotide_Resource', 'http://purl.uniprot.org/core/Nucleotide_Resource', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Nucleotide_Resource',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }