#' @title get_Disease
#' @description Disease
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * mnemonic -- A easy to remember identifier for a UniProtKB entry, but it is not a stable identifier and should not be used by programs to identify entries.
#'  * altLabel -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Disease <- function(properties = list(dataProperties = list(unique = c("mnemonic", "prefLabel"), nonunique = c("rdfs_comment", "altLabel"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(mnemonic = "http://purl.uniprot.org/core/mnemonic", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", rdfs_comment = "rdfs:comment", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("mnemonic", "prefLabel"), nonunique = c("rdfs_comment", "altLabel")))
   sparql <- makeSparql(propDict[flatProps],'Disease', 'http://purl.uniprot.org/core/Disease', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Disease',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }