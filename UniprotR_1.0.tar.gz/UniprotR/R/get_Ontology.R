#' @title get_Ontology
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * abstract -- -
#'  * description -- -
#'  * title -- -
#'  * preferredNamespacePrefix -- -
#'  * versionInfo -- -
#'  * introduction -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Ontology <- function(properties = list(literalProperties = list(unique = c("abstract", "description", "title", "preferredNamespacePrefix", "versionInfo", "introduction"), nonunique = c("rdfs:comment", "rdfs:label"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(abstract = "http://purl.org/dc/terms/abstract", description = "http://purl.org/dc/terms/description", title = "http://purl.org/dc/terms/title", preferredNamespacePrefix = "http://purl.org/vocab/vann/preferredNamespacePrefix", versionInfo = "http://www.w3.org/2002/07/owl#versionInfo", introduction = "https://w3id.org/widoco/vocab#introduction", `rdfs:comment` = "rdfs:comment", `rdfs:label` = "rdfs:label")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Ontology', 'http://www.w3.org/2002/07/owl#Ontology', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }