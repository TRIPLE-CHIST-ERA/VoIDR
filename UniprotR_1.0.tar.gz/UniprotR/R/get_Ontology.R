#' @title get_Ontology
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * abstract -- -
#'  * description -- -
#'  * title -- -
#'  * preferredNamespacePrefix -- -
#'  * introduction -- -
#'  * versionInfo -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Ontology <- function(properties = list(dataProperties = list(unique = c("abstract", "description", "title", "preferredNamespacePrefix", "versionInfo", "introduction"), nonunique = c("rdfs_comment", "rdfs_label"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(abstract = "http://purl.org/dc/terms/abstract", description = "http://purl.org/dc/terms/description", title = "http://purl.org/dc/terms/title", preferredNamespacePrefix = "http://purl.org/vocab/vann/preferredNamespacePrefix", versionInfo = "http://www.w3.org/2002/07/owl#versionInfo", introduction = "https://w3id.org/widoco/vocab#introduction", rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("abstract", "description", "title", "preferredNamespacePrefix", "versionInfo", "introduction"), nonunique = c("rdfs_comment", "rdfs_label")))
   sparql <- makeSparql(propDict[flatProps],'Ontology', 'http://www.w3.org/2002/07/owl#Ontology', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Ontology',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }