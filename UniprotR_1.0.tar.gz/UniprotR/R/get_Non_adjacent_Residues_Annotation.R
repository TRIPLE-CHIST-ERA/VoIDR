#' @title get_Non_adjacent_Residues_Annotation
#' @description Indicates that two residues in a sequence are not consecutive and that there are a number of unsequenced residues between them.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * range -- A specialization of faldo:location where all objects are faldo:Regions
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Non_adjacent_Residues_Annotation <- function(properties = list(objectProperties = list(nonunique = "range")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(range = "http://purl.uniprot.org/core/range")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(objectProperties = list(nonunique = "range"))
   sparql <- makeSparql(propDict[flatProps],'Non_adjacent_Residues_Annotation', 'http://purl.uniprot.org/core/Non-adjacent_Residues_Annotation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Non_adjacent_Residues_Annotation',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }