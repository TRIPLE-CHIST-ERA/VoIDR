#' @title get_Chain_Annotation
#' @description Extent of a polypeptide chain in the mature protein.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * mass -- The predicted mass of a sequence in Daltons.
#'  * range -- A specialization of faldo:location where all objects are faldo:Regions
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Chain_Annotation <- function(properties = c("rdfs:comment", "mass", "range"), limit = 1000){
    propDict <- list()
    propDict[c("rdfs:comment", "mass", "range")] <- c("rdfs:comment", "http://purl.uniprot.org/core/mass", "http://purl.uniprot.org/core/range")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Chain_Annotation a <',"http://purl.uniprot.org/core/Chain_Annotation",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Chain_Annotation ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }