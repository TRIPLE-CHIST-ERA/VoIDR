#' @title get_ExactPosition
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * position -- -
#'  * reference -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_ExactPosition <- function(properties = list(literalProperties = list(nonunique = "position"), iriProperties = list(nonunique = "reference")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(position = "http://biohackathon.org/resource/faldo#position", reference = "http://biohackathon.org/resource/faldo#reference")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = "position"), iriProperties = list(nonunique = "reference"))
   sparql <- makeSparql(propDict[flatProps],'ExactPosition', 'http://biohackathon.org/resource/faldo#ExactPosition', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('ExactPosition',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }