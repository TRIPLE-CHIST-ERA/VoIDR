#' @title get_Mass_Measurement_Method
#' @description An experimental method for measuring the mass of a molecule.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Mass_Measurement_Method <- function(properties = list(dataProperties = list(nonunique = c("rdfs_comment", "rdfs_label")), objectProperties = list(unique = "rdfs_isDefinedBy")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label", rdfs_isDefinedBy = "rdfs:isDefinedBy")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(nonunique = c("rdfs_comment", "rdfs_label")), objectProperties = list(unique = "rdfs_isDefinedBy"))
   sparql <- makeSparql(propDict[flatProps],'Mass_Measurement_Method', 'http://purl.uniprot.org/core/Mass_Measurement_Method', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Mass_Measurement_Method',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }