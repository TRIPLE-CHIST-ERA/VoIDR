#' @title get_rdfs_Datatype
#' @description get_rdfs_Datatype
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * oneOf -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_rdfs_Datatype <- function(properties = list(iriProperties = list(unique = "oneOf")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(oneOf = "http://www.w3.org/2002/07/owl#oneOf")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(iriProperties = list(unique = "oneOf"))
   sparql <- makeSparql(propDict[flatProps],'rdfs_Datatype', 'rdfs:Datatype', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('rdfs_Datatype',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }