#' @title get_SPARQLSelectExecutable
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * describe -- -
#'  * keyowrd -- -
#'  * keywords -- -
#'  * prefixes -- -
#'  * select -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_SPARQLSelectExecutable <- function(properties = list(dataProperties = list(unique = c("select", "describe"), nonunique = c("rdfs_comment", "rdfs_label", "keyowrd", "keyowrds", "keywords")), objectProperties = list(unique = "prefixes")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(select = "http://www.w3.org/ns/shacl#select", describe = "https://purl.expasy.org/sparql-examples/ontology#describe", rdfs_comment = "rdfs:comment", rdfs_label = "rdfs:label", keyowrd = "https://schema.org/keyowrd", keyowrds = "https://schema.org/keyowrds", keywords = "https://schema.org/keywords", prefixes = "http://www.w3.org/ns/shacl#prefixes")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("select", "describe"), nonunique = c("rdfs_comment", "rdfs_label", "keyowrd", "keyowrds", "keywords")), objectProperties = list(unique = "prefixes"))
   sparql <- makeSparql(propDict[flatProps],'SPARQLSelectExecutable', 'http://www.w3.org/ns/shacl#SPARQLSelectExecutable', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('SPARQLSelectExecutable',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }