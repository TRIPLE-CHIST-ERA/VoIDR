#' @title get_SPARQLSelectExecutable
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * describe -- -
#'  * keyowrd -- -
#'  * keyowrds -- -
#'  * select -- -
#'  * keywords -- -
#'  * prefixes -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_SPARQLSelectExecutable <- function(properties = list(literalProperties = list(unique = c("describe", "keyowrd", "keyowrds"), nonunique = c("rdfs:comment", "rdfs:label", "select", "keywords")), iriProperties = list(nonunique = "prefixes")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(describe = "https://purl.expasy.org/sparql-examples/ontology#describe", keyowrd = "https://schema.org/keyowrd", keyowrds = "https://schema.org/keyowrds", `rdfs:comment` = "rdfs:comment", `rdfs:label` = "rdfs:label", select = "http://www.w3.org/ns/shacl#select", keywords = "https://schema.org/keywords", prefixes = "http://www.w3.org/ns/shacl#prefixes")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'SPARQLSelectExecutable', 'http://www.w3.org/ns/shacl#SPARQLSelectExecutable', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }