#' @title get_Self_Interaction
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * experiments -- -
#'  * xeno -- -
#'  * participant -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Self_Interaction <- function(properties = list(literalProperties = list(nonunique = c("experiments", "xeno")), iriProperties = list(nonunique = "participant")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(experiments = "http://purl.uniprot.org/core/experiments", xeno = "http://purl.uniprot.org/core/xeno", participant = "http://purl.uniprot.org/core/participant")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Self_Interaction', 'http://purl.uniprot.org/core/Self_Interaction', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }