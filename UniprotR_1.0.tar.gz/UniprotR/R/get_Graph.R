#' @title get_Graph
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * distinctBlankNodeSubjects -- -
#'  * distinctIRIReferenceObjects -- -
#'  * distinctIRIReferenceSubjects -- -
#'  * distinctLiterals -- -
#'  * classes -- -
#'  * distinctObjects -- -
#'  * distinctSubjects -- -
#'  * triples -- -
#'  * classPartition -- -
#'  * subset -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Graph <- function(properties = list(literalProperties = list(unique = c("distinctBlankNodeSubjects", "distinctIRIReferenceObjects", "distinctIRIReferenceSubjects", "distinctLiterals"), nonunique = c("classes", "distinctObjects", "distinctSubjects", "triples")), iriProperties = list(unique = "classPartition", nonunique = "subset")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(distinctBlankNodeSubjects = "http://ldf.fi/void-ext#distinctBlankNodeSubjects", distinctIRIReferenceObjects = "http://ldf.fi/void-ext#distinctIRIReferenceObjects", distinctIRIReferenceSubjects = "http://ldf.fi/void-ext#distinctIRIReferenceSubjects", distinctLiterals = "http://ldf.fi/void-ext#distinctLiterals", classes = "http://rdfs.org/ns/void#classes", distinctObjects = "http://rdfs.org/ns/void#distinctObjects", distinctSubjects = "http://rdfs.org/ns/void#distinctSubjects", triples = "http://rdfs.org/ns/void#triples", 
    classPartition = "http://rdfs.org/ns/void#classPartition", subset = "http://rdfs.org/ns/void#subset")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Graph', 'http://www.w3.org/ns/sparql-service-description#Graph', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }