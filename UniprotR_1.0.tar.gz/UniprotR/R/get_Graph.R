#' @title get_Graph
#' @description get_Graph
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * distinctBlankNodeSubjects -- -
#'  * distinctIRIReferenceObjects -- -
#'  * distinctIRIReferenceSubjects -- -
#'  * distinctLiterals -- -
#'  * classes -- -
#'  * classPartition -- -
#'  * distinctObjects -- -
#'  * distinctSubjects -- -
#'  * subset -- -
#'  * triples -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Graph <- function(properties = list(dataProperties = list(unique = c("distinctBlankNodeSubjects", "distinctIRIReferenceObjects", "distinctIRIReferenceSubjects", "distinctLiterals", "classes", "distinctObjects", "distinctSubjects", "triples")), objectProperties = list(nonunique = c("classPartition", "subset"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(distinctBlankNodeSubjects = "http://ldf.fi/void-ext#distinctBlankNodeSubjects", distinctIRIReferenceObjects = "http://ldf.fi/void-ext#distinctIRIReferenceObjects", distinctIRIReferenceSubjects = "http://ldf.fi/void-ext#distinctIRIReferenceSubjects", distinctLiterals = "http://ldf.fi/void-ext#distinctLiterals", classes = "http://rdfs.org/ns/void#classes", distinctObjects = "http://rdfs.org/ns/void#distinctObjects", distinctSubjects = "http://rdfs.org/ns/void#distinctSubjects", triples = "http://rdfs.org/ns/void#triples", 
    classPartition = "http://rdfs.org/ns/void#classPartition", subset = "http://rdfs.org/ns/void#subset")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("distinctBlankNodeSubjects", "distinctIRIReferenceObjects", "distinctIRIReferenceSubjects", "distinctLiterals", "classes", "distinctObjects", "distinctSubjects", "triples")), objectProperties = list(nonunique = c("classPartition", "subset")))
   sparql <- makeSparql(propDict[flatProps],'Graph', 'http://www.w3.org/ns/sparql-service-description#Graph', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Graph',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }