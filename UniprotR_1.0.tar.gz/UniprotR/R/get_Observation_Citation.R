#' @title get_Observation_Citation
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * author -- -
#'  * date -- -
#'  * group -- -
#'  * title -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Observation_Citation <- function(properties = list(literalProperties = list(nonunique = c("author", "date", "group", "title"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(author = "http://purl.uniprot.org/core/author", date = "http://purl.uniprot.org/core/date", group = "http://purl.uniprot.org/core/group", title = "http://purl.uniprot.org/core/title")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Observation_Citation', 'http://purl.uniprot.org/core/Observation_Citation', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }