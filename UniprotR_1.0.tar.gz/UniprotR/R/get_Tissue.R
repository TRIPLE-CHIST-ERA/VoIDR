#' @title get_Tissue
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * altLabel -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Tissue <- function(properties = list(literalProperties = list(nonunique = c("rdfs:label", "altLabel", "prefLabel"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(`rdfs:label` = "rdfs:label", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Tissue', 'http://purl.uniprot.org/core/Tissue', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }