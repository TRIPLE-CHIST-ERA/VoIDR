#' @title get_Tissue
#' @description A tissue such as lung or heart.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * prefLabel -- -
#'  * altLabel -- -
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_Tissue <- function(properties = c("altLabel", "prefLabel"), limit = 10000){
    propDict <- list()
    propDict[c("altLabel", "prefLabel")] <- c("http://www.w3.org/2004/02/skos/core#altLabel", "http://www.w3.org/2004/02/skos/core#prefLabel")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Tissue a <',"http://purl.uniprot.org/core/Tissue",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Tissue ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }