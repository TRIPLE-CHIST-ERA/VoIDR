#' @title get_Mass_Spectrometry_Annotation
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * measuredError -- -
#'  * measuredValue -- -
#'  * sequence -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Mass_Spectrometry_Annotation <- function(properties = list(literalProperties = list(nonunique = c("measuredError", "measuredValue", "rdfs_comment")), iriProperties = list(nonunique = "sequence")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(measuredError = "http://purl.uniprot.org/core/measuredError", measuredValue = "http://purl.uniprot.org/core/measuredValue", rdfs_comment = "rdfs:comment", sequence = "http://purl.uniprot.org/core/sequence")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(literalProperties = list(nonunique = c("measuredError", "measuredValue", "rdfs_comment")), iriProperties = list(nonunique = "sequence"))
   sparql <- makeSparql(propDict[flatProps],'Mass_Spectrometry_Annotation', 'http://purl.uniprot.org/core/Mass_Spectrometry_Annotation', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    sapply(returnPattern, function(propType){
      sapply(propType, function(propCard){
      retDf[,c('Mass_Spectrometry_Annotation',intersect(propCard, retCols))]
      }, simplify = FALSE)
    }, simplify = FALSE)

  }