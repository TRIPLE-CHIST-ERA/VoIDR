#' @title get_Simple_Sequence
#' @description Simple Sequence
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * fragment -- Indicates if a sequence is complete or consists of one or more fragments.
#'  * mass -- The predicted mass of a sequence in Daltons.
#'  * md5Checksum -- MD5 checksum
#'  * modified -- The date a resource was last modified.
#'  * precursor -- precursor
#'  * version -- version
#'  * altLabel -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Simple_Sequence <- function(properties = list(dataProperties = list(unique = c("fragment", "md5Checksum", "modified", "precursor", "version", "rdf_value", "prefLabel"), nonunique = c("mass", "altLabel"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(fragment = "http://purl.uniprot.org/core/fragment", md5Checksum = "http://purl.uniprot.org/core/md5Checksum", modified = "http://purl.uniprot.org/core/modified", precursor = "http://purl.uniprot.org/core/precursor", version = "http://purl.uniprot.org/core/version", rdf_value = "rdf:value", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel", mass = "http://purl.uniprot.org/core/mass", altLabel = "http://www.w3.org/2004/02/skos/core#altLabel")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("fragment", "md5Checksum", "modified", "precursor", "version", "rdf_value", "prefLabel"), nonunique = c("mass", "altLabel")))
   sparql <- makeSparql(propDict[flatProps],'Simple_Sequence', 'http://purl.uniprot.org/core/Simple_Sequence', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retChunk <- retDf[,c('Simple_Sequence',actualCols)]
      retChunk[!duplicated(retChunk),]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'
    f <- function(x) cat(x)
    assign('print.sparql_string', f, envir = .GlobalEnv)

    return(ret[!sapply(ret,isEmpty)])
  }