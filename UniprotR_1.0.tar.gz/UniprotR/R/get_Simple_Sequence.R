#' @title get_Simple_Sequence
#' @description Simple Sequence
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * fragment -- Indicates if a sequence is complete or consists of one or more fragments.
#'  * mass -- The predicted mass of a sequence in Daltons.
#'  * modified -- The date a resource was last modified.
#'  * md5Checksum -- MD5 checksum
#'  * name -- name
#'  * precursor -- precursor
#'  * version -- version
#' @md
#' @param limit a numeric, how many lines to fetch, default 1000. If null, all the lines will be fetched.
get_Simple_Sequence <- function(properties = c("fragment", "mass", "md5Checksum", "modified", "name", "precursor", "rdf:value", "version"), limit = 10000){
    propDict <- list()
    propDict[c("fragment", "mass", "md5Checksum", "modified", "name", "precursor", "rdf:value", "version")] <- c("http://purl.uniprot.org/core/fragment", "http://purl.uniprot.org/core/mass", "http://purl.uniprot.org/core/md5Checksum", "http://purl.uniprot.org/core/modified", "http://purl.uniprot.org/core/name", "http://purl.uniprot.org/core/precursor", "rdf:value", "http://purl.uniprot.org/core/version")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Simple_Sequence a <',"http://purl.uniprot.org/core/Simple_Sequence",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Simple_Sequence ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }