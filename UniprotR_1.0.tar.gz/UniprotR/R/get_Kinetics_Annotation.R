#' @title get_Kinetics_Annotation
#' @description Mentions the Michaelis-Menten constant (KM) and maximal velocity (Vmax) of enzymes.
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * measuredActivity -- The maximum velocity, Vmax.
#'  * measuredAffinity -- The Michaelis-Menten constant, Km.
#'  * sequence -- An amino acid sequence.
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Kinetics_Annotation <- function(properties = c("rdfs:comment", "measuredActivity", "measuredAffinity", "sequence"), limit = 1000){
    propDict <- list()
    propDict[c("rdfs:comment", "measuredActivity", "measuredAffinity", "sequence")] <- c("rdfs:comment", "http://purl.uniprot.org/core/measuredActivity", "http://purl.uniprot.org/core/measuredAffinity", "http://purl.uniprot.org/core/sequence")
    propFilter <- paste(propDict[properties], collapse='> <')
    sparql <-  paste0('SELECT *
                  WHERE {
                    ?Kinetics_Annotation a <',"http://purl.uniprot.org/core/Kinetics_Annotation",'> .
                     VALUES ?p { <', propFilter, '> }
                    ?Kinetics_Annotation ?p ?value
                  }')
    if(!is.null(limit)){
      sparql <- paste0(sparql, ' LIMIT ', as.integer(limit))
    }
    long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
    if(is.null(long_df)){
      return(NULL)
    }
    wide_df <- tidyr::pivot_wider(long_df, id_cols= 1, names_from = 'p', values_from= 'value', values_fn = function(x)paste(x, collapse= '~~'))
    colnames(wide_df) <- sapply(colnames(wide_df), function(x) sub('.*[/|#]','',x))
    return(wide_df)

  }