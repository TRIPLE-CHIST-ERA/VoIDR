#' @title get_Unknown_Sequence
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * altLabel -- -
#'  * prefLabel -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_Unknown_Sequence <- function(properties = list(literalProperties = list(nonunique = c("altLabel", "prefLabel"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(altLabel = "http://www.w3.org/2004/02/skos/core#altLabel", prefLabel = "http://www.w3.org/2004/02/skos/core#prefLabel")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'Unknown_Sequence', 'http://purl.uniprot.org/core/Unknown_Sequence', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }