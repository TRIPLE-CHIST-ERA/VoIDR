#' @title get_SPARQLAskExecutable
#' @description -
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#'  * ask -- -
#'  * keywords -- -
#'  * prefixes -- -
#' @md
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
get_SPARQLAskExecutable <- function(properties = list(literalProperties = list(unique = "ask", nonunique = c("rdfs:comment", "keywords")), iriProperties = list(nonunique = "prefixes")), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(ask = "http://www.w3.org/ns/shacl#ask", `rdfs:comment` = "rdfs:comment", keywords = "https://schema.org/keywords", prefixes = "http://www.w3.org/ns/shacl#prefixes")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)

   sparql <- makeSparql(propDict[flatProps],'SPARQLAskExecutable', 'http://www.w3.org/ns/shacl#SPARQLAskExecutable', limit, only.complete.cases)
      long_df <- SPARQL_query('https://sparql.uniprot.org', sparql)
      if(is.null(long_df)){
       return(NULL)
     }
    return(long_df)

  }