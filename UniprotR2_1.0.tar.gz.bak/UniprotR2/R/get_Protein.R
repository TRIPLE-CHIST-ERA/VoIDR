#' @title get_Protein
#' @description get_Protein
#' @param properties a character vector, which properties of this class should be loaded. Properties will become columns of the result set.
#' @param limit a numeric, how many triples to fetch, default 1000. If null, all the triples will be fetched.
#' @param only.complete.cases a logical, fetch only rows where all the specified properties have a value? If FALSE (the default) NAs are allowed in the output.
get_Protein <- function(properties = list(dataProperties = list(unique = c("complete", "created", "mnemonic", "modified", "reviewed", "version", "obsolete", "withdrawnFromINSDC"), nonunique = "oldMnemonic"), objectProperties = list(unique = "recommendedName", nonunique = c("alternativeName", "annotation", "citation", "component", "conflictingSequence", "domain", "encodedBy", "encodedIn", "interaction", "isolatedFrom", "potentialSequence", "sequence", "submittedName", "rdfs_seeAlso", "replacedBy"))), limit = 1000, only.complete.cases = FALSE){
   propDict <- list(complete = "http://purl.uniprot.org/core/complete", created = "http://purl.uniprot.org/core/created", mnemonic = "http://purl.uniprot.org/core/mnemonic", modified = "http://purl.uniprot.org/core/modified", reviewed = "http://purl.uniprot.org/core/reviewed", version = "http://purl.uniprot.org/core/version", obsolete = "http://purl.uniprot.org/core/obsolete", withdrawnFromINSDC = "http://purl.uniprot.org/core/withdrawnFromINSDC", oldMnemonic = "http://purl.uniprot.org/core/oldMnemonic", recommendedName = "http://purl.uniprot.org/core/recommendedName", 
    alternativeName = "http://purl.uniprot.org/core/alternativeName", annotation = "http://purl.uniprot.org/core/annotation", citation = "http://purl.uniprot.org/core/citation", component = "http://purl.uniprot.org/core/component", conflictingSequence = "http://purl.uniprot.org/core/conflictingSequence", domain = "http://purl.uniprot.org/core/domain", encodedBy = "http://purl.uniprot.org/core/encodedBy", encodedIn = "http://purl.uniprot.org/core/encodedIn", interaction = "http://purl.uniprot.org/core/interaction", 
    isolatedFrom = "http://purl.uniprot.org/core/isolatedFrom", potentialSequence = "http://purl.uniprot.org/core/potentialSequence", sequence = "http://purl.uniprot.org/core/sequence", submittedName = "http://purl.uniprot.org/core/submittedName", rdfs_seeAlso = "rdfs:seeAlso", replacedBy = "http://purl.uniprot.org/core/replacedBy")
   isEmpty <- function(x) length(x) == 0
   flatProps <- unlist(properties, use.names = FALSE)
   returnPattern <- list(dataProperties = list(unique = c("complete", "created", "mnemonic", "modified", "reviewed", "version", "obsolete", "withdrawnFromINSDC"), nonunique = "oldMnemonic"), objectProperties = list(unique = "recommendedName", nonunique = c("alternativeName", "annotation", "citation", "component", "conflictingSequence", "domain", "encodedBy", "encodedIn", "interaction", "isolatedFrom", "potentialSequence", "sequence", "submittedName", "rdfs_seeAlso", "replacedBy")))
   sparql <- makeSparql(propDict[flatProps],'Protein', 'http://purl.uniprot.org/core/Protein', limit, only.complete.cases)
    retDf <- SPARQL_query('https://sparql.uniprot.org', sparql)
    retCols <- colnames(retDf)
    ret <- sapply(returnPattern, function(propType){
      out <- sapply(propType, function(propCard){
      actualCols <- intersect(propCard, retCols)
      if(length(actualCols) == 0){
        return(NULL)
      }
      retDf[,c('Protein',actualCols)]
      }, simplify = FALSE)
      return(out[!sapply(out, is.null)])
    }, simplify = FALSE)
    ret$sparql <- sparql
    class(ret$sparql) = 'sparql_string'

    return(ret[!sapply(ret,isEmpty)])
  }